
#include "DumpOBJ.h"
#include "DumpPE.h"
#include "common.h"
#include "CoffSym.h"

//
// prototypes
//
void  OBJ_DumpRelocations(void* pObj, PIMAGE_SECTION_HEADER pSH);
void  OBJ_DumpLinkerDirectiveObject(void* pObj, PIMAGE_SECTION_HEADER pSH);
//char* OBJ_SymbolIndex2Name(void* pObj, UINT index);
void  OBJ_GetSectionCountSizeFromSymTable(IN PIMAGE_SECTION_HEADER pSH, IN PIMAGE_FILE_HEADER pFH,
										  OUT PDWORD pdwCount, OUT PDWORD pdwSize);

//
// constants
//
WORD_FLAG_STR_TABLE ObjRelocTypesI386[] = 
{
	0x0000, "ABSOLUTE",
	0x0001, "DIR16",
	0x0002, "REL16",
	0x0006, "DIR32",
	0x0007, "DIR32NB",
	0x0009, "SEG12",
	0x000A, "SECTION",
	0x000B, "SECREL",
	0x000C, "TOKEN",
	0x000D, "SECREL7",
	0x0014, "REL32"
};

WORD_FLAG_STR_TABLE ObjRelocTypesIA64[] =
{
	0x0000, "ABSOLUTE",
	0x0001, "IMM14",
	0x0002, "IMM22",
	0x0003, "IMM64",
	0x0004, "DIR32",
	0x0005, "DIR64",
	0x0006, "PCREL21B",
	0x0007, "PCREL21M",
	0x0008, "PCREL21F",
	0x0009, "GPREL22",
	0x000A, "LTOFF22",
	0x000B, "SECTION",
	0x000C, "SECREL22",
	0x000D, "SECREL64I",
	0x000E, "SECREL32",
	0x0010, "DIR32NB",
	0x0011, "SREL14",
	0x0012, "SREL22",
	0x0013, "SREL32",
	0x0014, "UREL32",
	0x0015, "PCREL60X",
	0x0016, "PCREL60B",
	0x0017, "PCREL60F",
	0x0018, "PCREL60I",
	0x0019, "PCREL60M",
	0x001A, "IMMGPREL64",
	0x001B, "TOKEN",
	0x001C, "GPREL32",
	0x001F, "ADDEND"
};

WORD_FLAG_STR_TABLE ObjSymSectionNumber[] =
{
	0x0000, "UNDEFINED",
	(SHORT)-1, "ABSOLUTE",
	(SHORT)-2, "DEBUG"
};

WORD_FLAG_STR_TABLE ObjSymTypes[] =
{
	0x0000, "NO TYPE",
	0x0001, "VOID",
	0x0002, "CHAR",
	0x0003, "SHORT",
	0x0004, "INT",
	0x0005, "LONG",
	0x0006, "FLOAT",
	0x0007, "DOUBLE",
	0x0008, "STRUCT",
	0x0009, "UNION",
	0x000A, "ENUM",
	0x000B, "MOE",
	0x000C, "BYTE",
	0x000D, "WORD",
	0x000E, "UINT",
	0x000F, "DWORD",
	0x8000, "PCODE"
};

BYTE_FLAG_STR_TABLE ObjSymStorageClasses[] =
{
	(BYTE )-1, "END_OF_FUNCTION",
	0x0000, "NO CLASS",
	0x0001, "AUTOMATIC",
	0x0002, "EXTERNAL",
	0x0003, "STATIC",
	0x0004, "REGISTER",
	0x0005, "EXTERNAL_DEF",
	0x0006, "LABEL",
	0x0007, "UNDEFINED_LABEL",
	0x0008, "MEMBER_OF_STRUCT",
	0x0009, "ARGUMENT",
	0x000A, "STRUCT_TAG",
	0x000B, "MEMBER_OF_UNION",
	0x000C, "UNION_TAG",
	0x000D, "TYPE_DEFINITION",
	0x000E, "UNDEFINED_STATIC",
	0x000F, "ENUM_TAG",
	0x0010, "MEMBER_OF_ENUM",
	0x0011, "REGISTER_PARAM",
	0x0012, "BIT_FIELD",
	0x0044, "FAR_EXTERNAL",
	0x0064, "BLOCK",
	0x0065, "FUNCTION",
	0x0066, "END_OF_STRUCT",
	0x0067, "FILE",
	0x0068, "SECTION",
	0x0069, "WEAK_EXTERNAL",
	0x006B, "CLR_TOKEN"
};

BOOL IsCOFFObjectImage(void* pImage)
{
	UINT i;

	__try
	{
		// OptionalHeader present ?
		if (((PIMAGE_FILE_HEADER)pImage)->SizeOfOptionalHeader != 0)
			return FALSE; // ERR
		// known Machine ?
		if (((PIMAGE_FILE_HEADER)pImage)->Machine) // test only non-zero machine
			for (i = 0; i < ARRAY_ITEMS(PEMachine); i++)
				if (((PIMAGE_FILE_HEADER)pImage)->Machine == PEMachine[i].wFlag)
					return TRUE; // OK
	}
	__except(EXCEPTION_EXECUTE_HANDLER)
	{}
	//...

	return FALSE; // ERR
};

//
// OBJ header is simply a FileHeader and sometimes also with an OptionalHeader
//
BOOL OBJ_DumpHeader(void* pObj)
{
	PIMAGE_FILE_HEADER pFH = (PIMAGE_FILE_HEADER)pObj;

	PE_DumpFileHeader( pFH );

	return TRUE; // OK
}

BOOL OBJ_DumpOptionalHeader(void* pObj)
{
	PIMAGE_FILE_HEADER pFH = (PIMAGE_FILE_HEADER)pObj;

	PE_DumpOptionalHeader(
		(PIMAGE_OPTIONAL_HEADER)(pFH + 1),
		pFH);

	return TRUE; // OK
}

BOOL OBJ_DumpObjectHeaderTable(void* pObj)
{
	IMAGE_FILE_HEADER     *pIFH = (PIMAGE_FILE_HEADER)pObj;
	IMAGE_SECTION_HEADER  *pSH, *pFirstSH;
	UINT                  i;

	// print title
	printf("->Object Header Table\n");

	// common section header table ?
	if (!pIFH->NumberOfSections)
	{
		printf("   No SectionHeaders !\n\n");
		return FALSE; // ERR
	}

	//
	// trace SectionHeaders
	//
	pSH = pFirstSH = MakePtr(PIMAGE_SECTION_HEADER, pObj, sizeof(IMAGE_FILE_HEADER) +
		pIFH->SizeOfOptionalHeader);
	__try
	{
		for (i = 0; i < pIFH->NumberOfSections; i++)
		{
			// print index
			printf("   %u. Object Header:\n", i + 1);
			// dump hdr
			PE_DumpSectionHeader(pSH);
			// dump section relocations
			if (pSH->NumberOfRelocations)
			{
				printf("    Relocation items of %u. Object:\n", i + 1);
				OBJ_DumpRelocations(pObj, pSH);
				nextline;
			}
			// hex dump
			if (pSH->SizeOfRawData)
			{
				printf("    Hex dump of %u. Object:\n", i + 1);
				HexDump(
					MakePtr(PVOID, pObj, pSH->PointerToRawData),
					0,
					pSH->SizeOfRawData);
				nextline;
			}
			// eventually dump ".drectve" specific data
			if (memcmp(pSH->Name, &(".drectve"),8) == 0)
			{
				OBJ_DumpLinkerDirectiveObject(pObj, pSH);
				nextline;
			}
			// next hdr
			pSH++;
		}
		//
		// print section size summary
		//
		//OBJ_PrintSectionSizeSummary(pFirstSH, pIFH->NumberOfSections);
	}
	__except(EXCEPTION_EXECUTE_HANDLER)
	{
		nextline;
		printf("   Access violation !\n");
		nextline;
		return FALSE; // ERR
	}
	return TRUE; // OK
}

//
// PE32/PE32+ dependent but not tested
//
// (SEH by "OBJ_DumpObjectHeaderTable")
//
void OBJ_DumpRelocations(void* pObj, PIMAGE_SECTION_HEADER pSH)
{
	IMAGE_RELOCATION    *pItem = MakePtr(PIMAGE_RELOCATION, pObj, pSH->PointerToRelocations);
	UINT                i, u;
	char*               szType;
	PCOFF_SYMBOL_TABLE  pCSymTbl;
	PCOFF_SYMBOL        pCSym;

	if (!pSH->NumberOfRelocations) // any reloc items present ?
		return; // ERR

	// print grid header
	printf("    Offset     Type                 Sym. Index Symbol Name\n");
	printf("    ---------- -------------------- ---------- -----------------------------\n");
	// process items
	pCSymTbl = new COFF_SYMBOL_TABLE(
		MakePtr(PIMAGE_SYMBOL, pObj, ((PIMAGE_FILE_HEADER)pObj)->PointerToSymbolTable),
		((PIMAGE_FILE_HEADER)pObj)->NumberOfSymbols);
	for (i = 0; i < pSH->NumberOfRelocations; i++)
	{
		//
		// dump item
		//

		// get type str
		szType = "?";
		if (((PIMAGE_FILE_HEADER)pObj)->Machine == IMAGE_FILE_MACHINE_I386) // I386 architecture ?
		{
			for (u = 0; u < ARRAY_ITEMS(ObjRelocTypesI386); u++)
				if (ObjRelocTypesI386[u].wFlag == pItem->Type)
				{
					szType = ObjRelocTypesI386[u].szFlag;
					break;
				}
		}
		else if (((PIMAGE_FILE_HEADER)pObj)->Machine == IMAGE_FILE_MACHINE_IA64) // IA64 architecture ?
			for (u = 0; u < ARRAY_ITEMS(ObjRelocTypesIA64); u++)
				if (ObjRelocTypesIA64[u].wFlag == pItem->Type)
				{
					szType = ObjRelocTypesIA64[u].szFlag;
					break;
				}
		// print all except the symbol name
		printf("    "DWMASK" %-20s "DWMASK" ",
			pItem->VirtualAddress,
			szType,
			pItem->SymbolTableIndex);
		// try to print related symbol name
		pCSym = pCSymTbl->GetSymbolFromIndex(pItem->SymbolTableIndex);
		if (pCSym)
		{
			printf(pCSym->GetName());
			delete pCSym;
		}
		// next Relocation Item
		nextline;
		++pItem;
	}
	// cleanup
	delete pCSymTbl;

	return;
}

//
// dump ".drectve" objects
//
void OBJ_DumpLinkerDirectiveObject(void* pObj, PIMAGE_SECTION_HEADER pSH)
{
	char  cDirective[512], *pCH, *pchEnd;
	BOOL  bInQuotMarks;

	// print title
	printf("    Linker Directives:\n");

	//
	// dump linker directives (orientate on spaces as directive terminater)
	//
	pCH = MakePtr(PSTR, pObj, pSH->PointerToRawData);
	// find the first directory
	while ((DWORD)pCH < (DWORD)pObj + pSH->PointerToRawData + pSH->SizeOfRawData && *pCH == ' ')
		++pCH;
	// start
	pchEnd = pCH;
	bInQuotMarks = FALSE;
	while ((DWORD)pchEnd < (DWORD)pObj + pSH->PointerToRawData + pSH->SizeOfRawData) // pCH out of sec ?
	{
		// check for quotation mark
		if (*pchEnd == '"')
			bInQuotMarks = !bInQuotMarks;
		// space here ? - end of directive
		if ((*pchEnd != ' ' && *pchEnd != 0) || bInQuotMarks)
		{
			++pchEnd;
			continue;
		}
		// dump str
		lstrcpyn(
			cDirective,
			pCH,
			(DWORD)pchEnd - (DWORD)pCH + 1);
        printf("    %s\n", cDirective);
		pCH = pchEnd += 1;
	}

	return;
}

/*
//
// Returns:
// NULL     - if index out of range or symbol has no name
//
char* OBJ_SymbolIndex2Name(void* pObj, UINT index)
{
	DWORD dwNameRva;

	// out of range ?
	if (index >= ((PIMAGE_FILE_HEADER)pObj)->NumberOfSymbols)
		return NULL; // ERR

	dwNameRva = ((PIMAGE_COFF_SYMBOLS_HEADER) (((PIMAGE_FILE_HEADER)pObj)->PointerToSymbolTable +
		(DWORD)pObj + index * sizeof(IMAGE_COFF_SYMBOLS_HEADER)))->
	return NULL;
}
*/

//
// dump OBJs COFF symbol table
//
BOOL OBJ_DumpSymbolTable(void* pObj)
{
	IMAGE_SYMBOL               *pSym;
	IMAGE_FILE_HEADER          *pFH = (PIMAGE_FILE_HEADER)pObj;
	PCOFF_SYMBOL_TABLE         pCoffSymTbl;
	PCOFF_SYMBOL               pCoffSym;
	UINT                       i;
	char                       cSecNum[20], cType[20], cStorageClass[50], *szAuxSym;

	// print title
	printf("->Symbol Table\n");

	// present ?
	if (!pFH->PointerToSymbolTable || !pFH->NumberOfSymbols)
	{
		printf("   Not present or no symbols described in it !\n\n");
		return FALSE; // ERR
	}

	// get ptr
	pSym = MakePtr(PIMAGE_SYMBOL, pObj, ((PIMAGE_FILE_HEADER)pObj)->PointerToSymbolTable);
	pCoffSymTbl = new COFF_SYMBOL_TABLE(pSym, pFH->NumberOfSymbols);
	// print grid hdr
	printf("                                      Storage\n");
	printf("Index    Value    SecNum     Type     Class              Name\n");
	printf("-------- -------- ---------- -------- ------------------ -------------------\n");
	try
	{
		pCoffSym = pCoffSymTbl->GetNextSymbol(NULL);
		while (pCoffSym)
		{
			//
			// print symbol descriptor's information
			//

			// index
			printf(DWMASK_NO_PREFIX" ", pCoffSym->GetIndex());
			// value
			printf(DWMASK_NO_PREFIX" ", pCoffSym->GetValue());
			// section number
			cSecNum[0] = 0;
			for (i = 0; i < ARRAY_ITEMS(ObjSymSectionNumber); i++)
				if (ObjSymSectionNumber[i].wFlag == (WORD)pCoffSym->GetSectionNumber())
				{
					lstrcpy(cSecNum, ObjSymSectionNumber[i].szFlag);
					break;
				}
			if (!cSecNum[0])
				wsprintf(cSecNum, WMASK_NO_PREFIX"      ", (WORD)pCoffSym->GetSectionNumber());
			printf("%-10s ", cSecNum);
			// type
			cType[0] = 0;
			for (i = 0; i < ARRAY_ITEMS(ObjSymTypes); i++)
				if (ObjSymTypes[i].wFlag == pCoffSym->GetType())
				{
					lstrcpy(cType, ObjSymTypes[i].szFlag);
					break;
				}
			if (cType[0])
				printf("%-8s ", cType);
			else
				printf(WMASK_NO_PREFIX"     ", (WORD)pCoffSym->GetType());
			// storage class
			cStorageClass[0] = 0;
			for (i = 0; i < ARRAY_ITEMS(ObjSymStorageClasses); i++)
				if (ObjSymStorageClasses[i].byFlag == pCoffSym->GetStorageClass())
				{
					lstrcpy(cStorageClass, ObjSymStorageClasses[i].szFlag);
					break;
				}
			if (cStorageClass[0])
				printf("%-18s ", cStorageClass);
			else
				printf(BMASK_NO_PREFIX"                 ", (BYTE)pCoffSym->GetStorageClass());
			// name
			printf("%s\n", pCoffSym->GetName());

			//
			// dump aux symbols
			//
			szAuxSym = pCoffSym->GetAuxSymStr();
			if (szAuxSym)
				printf("   AuxSym:  %s\n", szAuxSym);

			pCoffSym = pCoffSymTbl->GetNextSymbol(pCoffSym); // next symbol descr
		}
	}
	//__except(EXCEPTION_EXECUTE_HANDLER)
	catch(...)
	{
		nextline;
		printf("Access violation !\n");
		nextline;
		delete pCoffSymTbl;
		delete pCoffSym;
		return FALSE; // ERR
	}
	delete pCoffSymTbl;
	nextline;

	return TRUE; // OK
}

//
//
//
void OBJ_GetSectionCountSizeFromSymTable(IN PIMAGE_SECTION_HEADER pSH, IN PIMAGE_FILE_HEADER pFH,
										 OUT PDWORD pdwCount, OUT PDWORD pdwSize)
{
	PCOFF_SYMBOL_TABLE pCSymTbl;
	PCOFF_SYMBOL       pCSym;
	IMAGE_AUX_SYMBOL   *pAuxSym;
	DWORD              dwSize, dwCnt;

	// preinitialize input vars
	*pdwCount = 0;
	*pdwSize  = 0;

	if (!pFH->PointerToSymbolTable || !pFH->NumberOfSymbols)
		return; // ERR

	//
	// trace symbol table
	//
	try
	{
		//
		// create sym tbl cls instances
		//
		pCSymTbl = new COFF_SYMBOL_TABLE(
			MakePtr(PIMAGE_SYMBOL, pFH, pFH->PointerToSymbolTable),
			pFH->NumberOfSymbols);
		pCSym = pCSymTbl->GetNextSymbol(NULL);
		dwSize = dwCnt = 0;
		do
		{
			if (pCSym->GetStorageClass() == IMAGE_SYM_CLASS_STATIC // STATIC symbol of our section ?
				&& pCSym->GetAuxSymNum() != 0                      // any aux syms present ?
				&& memcmp(&pSH->Name, (void*)pCSym->GetName(), 8) == 0) // sym name == sec name ?
			{
				// add to counters
				pAuxSym = (PIMAGE_AUX_SYMBOL)(pCSym->m_pSym + 1);
				dwSize += pAuxSym->Section.Length;
				dwCnt++;
			}
			pCSym = pCSymTbl->GetNextSymbol(pCSym);
		} while (pCSym); // until all syms done
	}
	catch(...)
	{
		delete pCSymTbl;
		delete pCSym;
		return; // ERR
	}

	// cleanup
	delete pCSymTbl;
	// set output vars
	*pdwCount = dwCnt;
	*pdwSize  = dwSize;

	return;
}

void OBJ_PrintSummary(void* pObj)
{
	IMAGE_FILE_HEADER     *pFH = (PIMAGE_FILE_HEADER)pObj;
	UINT                  i, i2, iSecCount, iSecCntInSymTbl;
	IMAGE_SECTION_HEADER  *pSH, *pSH2, *pFirstSH;
	DWORD                 dwTotalSize, dwSecSize;
	char                  cSec[9];

	// print title
	printf("->Object Module Summary\n");

	// get ptr to first section
	if (!pFH->NumberOfSections)
	{
		printf("   No section !\n\n");
		return; // ERR
	}
	pFirstSH = MakePtr(PIMAGE_SECTION_HEADER, pObj, sizeof(IMAGE_FILE_HEADER) +
		pFH->SizeOfOptionalHeader);

	__try
	{
		//
		// print total section sizes
		//

		// print grid hdr
		nextline;
		printf("                Section Header Table:     Symbol Table:\n");
		printf("   Section Name      Count Size            Count Size\n");
		printf("   ------------ ---------- ---------- ---------- ----------\n");
		pSH = pSH2 = pFirstSH;
		for (i = 0; i < pFH->NumberOfSections; i++)
		{
			// is this a already process section ?
			pSH2 = pFirstSH;
			for (i2 = 0; i2 < i; i2++)
			{
				if (memcmp(&pSH2->Name, &pSH->Name, 8) == 0)
					goto CheckNextSection;
				++pSH2;
			}
			// get total section size from symbol table
			dwSecSize = iSecCount = 0;
			pSH2 = pFirstSH;
			for (i2 = 0; i2 < pFH->NumberOfSections; i2++)
			{
				if (memcmp(&pSH2->Name, &pSH->Name, 8) == 0)
				{
					dwSecSize += pSH2->SizeOfRawData;
					++iSecCount;
				}
				++pSH2;
			}
            OBJ_GetSectionCountSizeFromSymTable(pSH, pFH, (PDWORD)&iSecCntInSymTbl, &dwTotalSize);
			ExtractSectionName(pSH, cSec, sizeof(cSec));
			printf("   %-12s "DWMASK" "DWMASK" "DWMASK" "DWMASK"\n",
				cSec, iSecCount, dwSecSize, iSecCntInSymTbl, dwTotalSize);
			// next section header
	CheckNextSection:
			++pSH;
		}
	}
	__except(EXCEPTION_EXECUTE_HANDLER)
	{
		nextline;
		printf("   Access violation !\n");
		nextline;
		return; // ERR
	}
	nextline;

	return;
}