
#ifndef __CoffSym_h__
#define __CoffSym_h__

#include <windows.h>

//
// COFF_SYMBOL class
//
class COFF_SYMBOL
{
public:
	DWORD         m_dwIndex;
	IMAGE_SYMBOL  *m_pSym;
	void*         m_pShortSymNameMem, *m_pStrTableBase;
	char          m_cType[10], m_cAuxSym[1024];

	              COFF_SYMBOL(PIMAGE_SYMBOL pSym, DWORD index, void* pStrTable);
	              ~COFF_SYMBOL();
	BOOL          CleanupShortNameMem();
	DWORD         GetIndex() { return m_dwIndex; }
	DWORD         GetValue() { return m_pSym->Value; }
	SHORT         GetSectionNumber() { return m_pSym->SectionNumber; }
	char*         GetName();
	WORD          GetType() { return m_pSym->Type; }
	BYTE          GetStorageClass() { return m_pSym->StorageClass; }
	BYTE          GetAuxSymNum() { return m_pSym->NumberOfAuxSymbols; }
	char*         GetAuxSymStr();

private:

};

typedef COFF_SYMBOL *PCOFF_SYMBOL;

//
// COFF_SYMBOL_TABLE class
//
class COFF_SYMBOL_TABLE
{
public:
	COFF_SYMBOL_TABLE(PIMAGE_SYMBOL pFirstSym, DWORD dwcSym);
	~COFF_SYMBOL_TABLE();
	PCOFF_SYMBOL  GetNextSymbol(PCOFF_SYMBOL pSym);
	PCOFF_SYMBOL  GetSymbolFromIndex(DWORD index);

private:
	void*         m_pSymStrTable;
	IMAGE_SYMBOL  *m_pFirstSym;
	DWORD         m_dwcSym;
};

typedef COFF_SYMBOL_TABLE *PCOFF_SYMBOL_TABLE;

#endif // __CoffSym_h__