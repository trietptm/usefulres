/*

  PESnoop
  -------

  advanced PE32/PE32+/COFF OBJ,LIB command line dumper

  project start: 27th March 2002

  by yoda

*/

#define  WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "PESnoop.h"
#include "common.h"
#include "DumpPE.h"
#include "DumpOBJ.h"
#include "DumpCoffLib.h"

#include "NoMsvcr70.h"
// optimization
#if !defined(_DEBUG)
#pragma comment(linker, "/MERGE:.rdata=.text /MERGE:.data=.text /SECTION:.text,REW")
#endif

//
// prototypes
//

//
// constants
//
#define TITLE   "-------------------------------------------------------------------------------\n" \
	            " PESnoop 2.0 - Advanced PE32/PE32+/COFF OBJ,LIB command line dumper by yoda\n" \
                "-------------------------------------------------------------------------------\n"
#define MINI_TITLE          "[ PESnoop ]"
#define CMD_LINE            "Usage: PESnoop.EXE (file path) (options)\n" \
	                        "  /NOLOGO    - skip title, input file path, modus\n" \
	                        "  /PE_DH     - dump DOS Header\n" \
							"  /PE_NH     - dump NT Headers\n" \
                            "  /PE_SHT    - dump SectionHeaderTable\n" \
                            "  /PE_ET     - dump ExportTable\n" \
                            "  /PE_IT     - dump ImportTable\n" \
                            "  /PE_RT     - simple ResourceTree dump\n" \
							"  /PE_RT+    - advanced ResourceTree dump\n" \
							"  /PE_ED     - dump ExceptionDirectory\n" \
							"  /PE_RD     - dump Relocation blocks\n" \
							"  /PE_DD     - dump DebugDirectory\n" \
							"  /PE_AD     - dump ArchitectureDirectory\n" \
							"  /PE_TT     - dump TLSTable\n" \
							"  /PE_LCD    - dump LoadConfigDirectory\n" \
							"  /PE_BI     - dump BoundImports\n" \
							"  /PE_DI     - dump DelayImports\n" \
							"  /PE_CD     - dump COMDirectory\n" \
							"  /PE_P      - hex dump image partitions\n" \
						    "  /PE_ALL    - dump everything\n" \
							"  /OBJ_FH    - dump FileHeader\n" \
							"  /OBJ_OH    - dump OptionalHeader\n" \
							"  /OBJ_SHT   - dump SectionHeaderTable\n" \
							"  /OBJ_ST    - dump SymbolTable\n" \
							"  /OBJ_S     - show Object Module summary\n" \
							"  /OBJ_ALL   - dump everything\n" \
							"  /LIB_AMH   - dump ArchiveMemberHeaders\n" \
							"  /LIB_ILR   - dump ImportLibraryRecords\n" \
							"  /LIB_LM    - dump LinkerMembers\n" \
							"  /LIB_LNM   - dump LongNamesMembers\n" \
							"  /LIB_OBJ_* - dump structures from Object Module Image Parts\n" \
							"  /LIB_S     - show Library summary\n" \
							"  /LIB_ALL   - dump everything\n" \
							"\n" \
							"Option flags are handled case insensitive.\n" \
							"Have a nice day..."

const char* szInputTypes[] =
{
	"32bit Portable Executable Image",
	"64bit Portable Executable Image",
	"COFF Object Module Image",
	"COFF Library Image",
};

//
// types
//
typedef enum _INPUT_TYPE
{
	INPUT_PE32 = 0,
	INPUT_PE64 = 1,
	INPUT_COFF_OBJ = 2,
	INPUT_COFF_LIB = 3,
	INPUT_UNSUPPORTED
} INPUT_TYPE, *PINPUT_TYPE;

//
// global variables
//
PE_HINTS            PE;
INPUT_TYPE          InputType;

int main(int argc, char* argv[])
{
	BOOL   bNoLogo;
	DWORD  i, dwFlags = 0;
	void*  pMap;

	//
	// initialization
	//
	SetConsoleTitle(MINI_TITLE);

	// check for /NOLOGO arg and set flag
	bNoLogo = FALSE;
	for(i = 0; i < (DWORD)argc; i++)
		if (lstrcmpi(argv[i], "/NOLOGO") == 0)
		{
			bNoLogo = TRUE;
			break;
		}

	//
	// print title
	//
	if (!bNoLogo)
	{
        printf(TITLE);
		newline
	}

	//
	// command line handling...
	//
	if (argc < 3 + bNoLogo)
	{
		printf("Not enough arguments !\n");
		nextline;
		printf(CMD_LINE);
		//getch();
		goto Quit;
	}

	//
	// map file
	//
	pMap = PE.pImage = MapFileR(argv[1]);
	if (!PE.pImage)
	{
		printf("Error while mapping target file into memory !\n");
		goto Quit;
	}

	//
	// check file image type
	//
	InputType = INPUT_UNSUPPORTED;
	PE.pNT = ImageNtHeader(PE.pImage);
	if (PE.pNT)
	{
		PE.b64Bit = PE_IsPE64(PE.pDH);
		InputType = PE.b64Bit ? INPUT_PE64 : INPUT_PE32;
	}
	else if ( IsCOFFObjectImage(pMap) )
		InputType = INPUT_COFF_OBJ;
	else if ( CLIB_IsCoffLibraryImage(pMap) )
		InputType = INPUT_COFF_LIB;
	else	
	{
		printf("Input file is neither a PE, a COFF OBJ nor a COFF LIB image !\n");
		goto Cleanup;
	}

	// print target file + input modues
	if (!bNoLogo)
	{
		printf("Dump of file: %s...\n", argv[1]);
		printf("Modus:        %s...\n", szInputTypes[InputType]);
		nextline;
	}

	//
	// dump structures
	//
	switch(InputType)
	{
	case INPUT_PE32:
	case INPUT_PE64:
		for (i = 2; i < (UINT)argc; i++)
		{
			if (lstrcmpi(argv[i], "/NOLOGO") == 0)// avoid unknown cmd complain
			{}
			else if (lstrcmpi(argv[i], "/PE_DH") == 0)
				PE_DumpDosHeader(PE.pImage);
			else if (lstrcmpi(argv[i], "/PE_NH") == 0)
				PE_DumpNtHeaders(&PE);
			else if (lstrcmpi(argv[i], "/PE_SHT") == 0)
				PE_DumpObjectTable(PE.pNT);
			else if (lstrcmpi(argv[i], "/PE_ET") == 0)
				PE_DumpExportTable(&PE);
			else if (lstrcmpi(argv[i], "/PE_IT") == 0)
				PE_DumpImportTable(&PE);
			else if (lstrcmpi(argv[i], "/PE_RT") == 0)
				PE_DumpResourceDirectory(&PE, FALSE);
			else if (lstrcmpi(argv[i], "/PE_RT+") == 0)
				PE_DumpResourceDirectory(&PE, TRUE);
			else if (lstrcmpi(argv[i], "/PE_ED") == 0)
				PE_DumpExceptionDirectory(&PE);
			else if (lstrcmpi(argv[i], "/PE_RD") == 0)
				PE_DumpBaseRelocation(&PE);
			else if (lstrcmpi(argv[i], "/PE_DD") == 0)
				PE_DumpDebugDirectory(&PE);
			else if (lstrcmpi(argv[i], "/PE_AD") == 0)
				PE_DumpCopyrightsDirectory(&PE);
			else if (lstrcmpi(argv[i], "/PE_TT") == 0)
				PE_DumpTLSTable(&PE);
			else if (lstrcmpi(argv[i], "/PE_LCD") == 0)
				PE_DumpLoadConfigDirectory(&PE);
			else if (lstrcmpi(argv[i], "/PE_BI") == 0)
				PE_DumpBoundImportDirectory(&PE);
			else if (lstrcmpi(argv[i], "/PE_DI") == 0)
				PE_DumpDelayImports(&PE);
			else if (lstrcmpi(argv[i], "/PE_CD") == 0)
				PE_DumpCOMDirectory(&PE);
			else if (lstrcmpi(argv[i], "/PE_P") == 0)
				PE_DumpImagePartitions(&PE);
			else if (lstrcmpi(argv[i], "/PE_ALL") == 0)
			{
				PE_DumpDosHeader(PE.pImage);
				PE_DumpNtHeaders(&PE);
				PE_DumpObjectTable(PE.pNT);
				PE_DumpExportTable(&PE);
				PE_DumpImportTable(&PE);
				PE_DumpResourceDirectory(&PE, TRUE);
				PE_DumpExceptionDirectory(&PE);
				PE_DumpBaseRelocation(&PE);
				PE_DumpDebugDirectory(&PE);
				PE_DumpCopyrightsDirectory(&PE);
				PE_DumpTLSTable(&PE);
				PE_DumpLoadConfigDirectory(&PE);
				PE_DumpBoundImportDirectory(&PE);
				PE_DumpDelayImports(&PE);
				PE_DumpCOMDirectory(&PE);
				PE_DumpImagePartitions(&PE);
			}
			else
				printf("Unknown or in modus unallowed command: \"%s\" !\n\n", argv[i]);
		}
		break;

	case INPUT_COFF_OBJ:
		for (i = 2; i < (UINT)argc; i++)
		{
			if (lstrcmpi(argv[i], "/NOLOGO") == 0)// avoid unknown cmd complain
			{}
			else if (lstrcmpi(argv[i], "/OBJ_FH") == 0)
				OBJ_DumpHeader(pMap);
			else if (lstrcmpi(argv[i], "/OBJ_OH") == 0)
				OBJ_DumpOptionalHeader(pMap);
			else if (lstrcmpi(argv[i], "/OBJ_SHT") == 0)
				OBJ_DumpObjectHeaderTable(pMap);
			else if (lstrcmpi(argv[i], "/OBJ_ST") == 0)
				OBJ_DumpSymbolTable(pMap);
			else if (lstrcmpi(argv[i], "/OBJ_S") == 0)
				OBJ_PrintSummary(pMap);
			else if (lstrcmpi(argv[i], "/OBJ_ALL") == 0)
			{
				OBJ_DumpHeader(pMap);
				OBJ_DumpOptionalHeader(pMap);
				OBJ_DumpObjectHeaderTable(pMap);
				OBJ_DumpSymbolTable(pMap);
				OBJ_PrintSummary(pMap);
			}
			else
				printf("Unknown or in current modus unallowed command: \"%s\" !\n\n", argv[i]);
		}
		break;

	case INPUT_COFF_LIB:
		// here it works different: first we process the command line and save the information
		// as flags and afterwards a top handler is called
		for (i = 2; i < (UINT)argc; i++)
		{
			if (lstrcmpi(argv[i], "/NOLOGO") == 0) // avoid unknown cmd complain
			{}
			else if (lstrcmpi(argv[i], "/LIB_OBJ_FH") == 0)
				dwFlags |= CMD_OBJ_FH;
			else if (lstrcmpi(argv[i], "/LIB_OBJ_OH") == 0)
				dwFlags |= CMD_OBJ_OH;
			else if (lstrcmpi(argv[i], "/LIB_OBJ_SHT") == 0)
				dwFlags |= CMD_OBJ_SHT;
			else if (lstrcmpi(argv[i], "/LIB_OBJ_ST") == 0)
				dwFlags |= CMD_OBJ_ST;
			else if (lstrcmpi(argv[i], "/LIB_OBJ_S") == 0)
				dwFlags |= CMD_OBJ_S;
			else if (lstrcmpi(argv[i], "/LIB_OBJ_ALL") == 0)
				dwFlags |= CMD_OBJ_ALL;
			else if (lstrcmpi(argv[i], "/LIB_AMH") == 0)
				dwFlags |= CMD_LIB_AMH;
			else if (lstrcmpi(argv[i], "/LIB_ILR") == 0)
				dwFlags |= CMD_LIB_ILR;
			else if (lstrcmpi(argv[i], "/LIB_LM") == 0)
				dwFlags |= CMD_LIB_LM;
			else if (lstrcmpi(argv[i], "/LIB_LNM") == 0)
				dwFlags |= CMD_LIB_LNM;
			else if (lstrcmpi(argv[i], "/LIB_S") == 0)
				dwFlags |= CMD_LIB_S;
			else if (lstrcmpi(argv[i], "/LIB_ALL") == 0)
				dwFlags |= CMD_LIB_ALL | CMD_OBJ_ALL;
			else
                printf("Unknown or in modus unallowed command: \"%s\" !\n\n", argv[i]);
		}
		//
		// call the top lister
		//
		if (!dwFlags)
			printf("Nothing to list specified !\n");
		else
            CLIB_DumpLibraryImage(pMap, dwFlags);
		break;
	}

	//
	// cleanup
	//
Cleanup:
	UnmapViewOfFile(PE.pImage);	

Quit:
	return 0;
}
