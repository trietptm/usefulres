
#ifndef __common_h__
#define __common_h__

#include <windows.h>
#include <imagehlp.h>
#include <delayimp.h>
#include <stdio.h>
#include <conio.h>
#include <stddef.h>
#include "time.h"

#pragma comment(lib, "imagehlp.lib")

//
// exported functions
//
LPVOID  MapFileR(char * targetfile);
BOOL    WipeCarriageReturn(char* szStr);
BOOL    WideToSingleCharStrN(IN PWSTR szWideStr, IN DWORD dwcMaxCharToProcess, OUT PSTR szStrBuff,
							 IN DWORD dwcBuff);
DWORD   EndianSwitch(IN DWORD dwVal);

//
// macros
//
#define newline                          printf("\n");
#define nextline                         printf("\n")
#define MakePtr( cast, ptr, addValue )   (cast)( (DWORD)(ptr) + (DWORD)(addValue))
#define ARRAY_ITEMS(name)                (sizeof(name) / sizeof(name[0]))
#define ZERO(strct)                      memset(&strct, 0, sizeof(strct));
#define TESTFLAG(val, flag)              (BOOL)((val & flag) == flag ? TRUE : FALSE)
#define TESTBIT(val, flag)               (BOOL)((val & flag) == 0 ? FALSE : TRUE)

//
// constants
//
#define BMASK                        "0x%02lX"
#define WMASK                        "0x%04lX"
#define DWMASK                       "0x%08lX"
#define QWMASK                       "0x%016lI64X"
#define HEXMASK_S                    "0x%X"
#define BMASK_NO_PREFIX              "%02lX"
#define WMASK_NO_PREFIX              "%04lX"
#define DWMASK_NO_PREFIX             "%08lX"

#define SHORT_NOT_PRESENT            "n/a"
#define SHORT_NOT_SHOWN              "[...]"

#endif // __common_h__