//
// prevent importation of msvcr70.dll (.NET C runtime library)
//
#if !defined(_DEBUG)
#pragma message("Exporting msvcrt.lib...Importing msvcrt.lib of VC6 !")
#pragma comment(linker, "/NODEFAULTLIB:msvcrt.lib /DEFAULTLIB:msvcrt_old.lib")
#else
#pragma message("Exporting msvcrtd.lib...Importing msvcrtd.lib of VC6 !")
#pragma comment(linker, "/NODEFAULTLIB:msvcrtd.lib /DEFAULTLIB:msvcrtd_old.lib")
#endif