
#include "CoffSym.h"
#include "common.h"
#include "DumpPE.h"

BYTE_FLAG_STR_TABLE szObjSymbolSelectionTypes[] =
{
	1, "NODUPLICATES",
	2, "ANY",
	3, "SAME_SIZE",
	4, "EXACT_MATCH",
	5, "ASSOCIATIVE",
	6, "LARGEST",
	7, "NEWEST"
};

// ---------------------------------------------------------
// COFF_SYMBOL class member functions
// ---------------------------------------------------------
COFF_SYMBOL::COFF_SYMBOL(PIMAGE_SYMBOL pSym, DWORD index, void* pStrTable)
{
	m_pSym               = pSym;
	m_dwIndex            = index;
	m_pShortSymNameMem   = NULL;
	m_pStrTableBase      = pStrTable;
}

COFF_SYMBOL::~COFF_SYMBOL()
{
	CleanupShortNameMem();
}

//
// Returns:
// TRUE     - if there was sth to cleanup
//
BOOL COFF_SYMBOL::CleanupShortNameMem()
{
	if (m_pShortSymNameMem)
	{
		free(m_pShortSymNameMem);
		m_pShortSymNameMem = NULL;
		return TRUE; // OK
	}
	else
		return FALSE; // ERR
}

char* COFF_SYMBOL::GetName()
{
	if (m_pSym->N.Name.Short != 0)
	{
		// return short name
		CleanupShortNameMem();
		m_pShortSymNameMem = malloc(9);
		if (!m_pShortSymNameMem)
			return NULL; // ERR
		memset(m_pShortSymNameMem, 0, 8);
		lstrcpyn(
			(char*)m_pShortSymNameMem,
			(char*)&m_pSym->N.ShortName,
			9);
		return (char*)m_pShortSymNameMem;
	}
	else
	{
		// return long name
		return MakePtr(PSTR, m_pStrTableBase, m_pSym->N.Name.Long);
	}
}

//
// interpret auxiliary simbols
//
char* COFF_SYMBOL::GetAuxSymStr()
{
	IMAGE_AUX_SYMBOL  *pAuxSym = (PIMAGE_AUX_SYMBOL)(m_pSym + 1);
	DWORD             *pdwClrTok;
	char              cSel[40];
	UINT              i;

	if (!m_pSym->NumberOfAuxSymbols)
		return NULL; // ERR

	//
	// dump aux symbols (storage class dependent)
	//
	switch(m_pSym->StorageClass)
	{
	case IMAGE_SYM_CLASS_FILE:
		lstrcpyn(m_cAuxSym, (char*)pAuxSym, sizeof(m_cAuxSym));
		break;

	case IMAGE_SYM_CLASS_STATIC:
		cSel[0] = 0;
		for (i = 0; i < ARRAY_ITEMS(szObjSymbolSelectionTypes); i++)
			if (szObjSymbolSelectionTypes[i].byFlag == pAuxSym->Section.Selection)
			{
				lstrcpy(cSel, szObjSymbolSelectionTypes[i].szFlag);
				break;
			}
		if (!cSel[0])
			wsprintf(cSel, HEXMASK_S, pAuxSym->Section.Selection);
		wsprintf(
			m_cAuxSym,
			"SecNum:"HEXMASK_S" Len:"HEXMASK_S" RelocNum:"HEXMASK_S" LineNums:"HEXMASK_S\
				" Sel:%s CheckSum:"HEXMASK_S,
			pAuxSym->Section.Number,
			pAuxSym->Section.Length,
			pAuxSym->Section.NumberOfRelocations,
			pAuxSym->Section.NumberOfLinenumbers,
			cSel,
			pAuxSym->Section.CheckSum);
		break;

	case IMAGE_SYM_CLASS_FUNCTION:
		wsprintf(
			m_cAuxSym,
			"Line:"HEXMASK_S" TotalSize:"HEXMASK_S" PtrToNextFunc:"HEXMASK_S,
            pAuxSym->Sym.Misc.LnSz.Linenumber,
            pAuxSym->Sym.Misc.TotalSize,
            pAuxSym->Sym.FcnAry.Function.PointerToNextFunction);
		break;

	case IMAGE_SYM_CLASS_CLR_TOKEN:
		pdwClrTok = (PDWORD)pAuxSym;
		wsprintf(
			m_cAuxSym,
			"Value1:"HEXMASK_S" Value2:"HEXMASK_S,
			*pdwClrTok,
			*(pdwClrTok + 1));
		break;

	case IMAGE_SYM_CLASS_EXTERNAL:
		if ((m_pSym->Type & N_TMASK2) == (IMAGE_SYM_DTYPE_FUNCTION << N_BTSHFT))
		{
			wsprintf(
				m_cAuxSym,
				"Tag:"HEXMASK_S" Size:"HEXMASK_S" Lines: "HEXMASK_S" PtrToNextFunc:"HEXMASK_S,
				pAuxSym->Sym.TagIndex,
				pAuxSym->Sym.Misc.TotalSize,
				pAuxSym->Sym.FcnAry.Function.PointerToLinenumber,
				pAuxSym->Sym.FcnAry.Function.PointerToNextFunction);
			break;
		}
		//...

	default:
		lstrcpy(m_cAuxSym, "Not handled");
	}

	return m_cAuxSym; // OK
}

// ---------------------------------------------------------
// COFF_SYMBOL_TABLE class member functions
// ---------------------------------------------------------
COFF_SYMBOL_TABLE::COFF_SYMBOL_TABLE(PIMAGE_SYMBOL pFirstSym, DWORD dwcSym)
{
	m_pSymStrTable   = MakePtr(PVOID, pFirstSym, dwcSym * sizeof(IMAGE_SYMBOL));
	m_pFirstSym      = pFirstSym;
	m_dwcSym         = dwcSym;
}

COFF_SYMBOL_TABLE::~COFF_SYMBOL_TABLE()
{}

//
// Args:
// pSym  - 0 indicates that a ptr to the first symbol should be returned
//
PCOFF_SYMBOL COFF_SYMBOL_TABLE::GetNextSymbol(PCOFF_SYMBOL pSym)
{
	if (!pSym) // 0 ? - return first sym ptr
		return new COFF_SYMBOL(m_pFirstSym, 0, m_pSymStrTable);

	// is it the last symbol ?
	if (pSym->m_dwIndex + pSym->m_pSym->NumberOfAuxSymbols + 1 >= m_dwcSym)
	{
		delete pSym;
		return 0; // ERR - no next symbol
	}

	// simply change member variables of the COFF_SYMBOL object
	pSym->CleanupShortNameMem();
	pSym->m_dwIndex += (1 + pSym->m_pSym->NumberOfAuxSymbols);
	pSym->m_pSym    += (1 + pSym->m_pSym->NumberOfAuxSymbols);
	return pSym; // OK
}

//
// Returns:
// NULL     - error
//
PCOFF_SYMBOL COFF_SYMBOL_TABLE::GetSymbolFromIndex(DWORD index)
{
	// index out of range ?
	if (index >= m_dwcSym)
		return NULL;

	return new COFF_SYMBOL(m_pFirstSym + index, index, m_pSymStrTable);
}