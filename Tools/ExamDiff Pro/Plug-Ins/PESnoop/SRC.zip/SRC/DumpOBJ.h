
#ifndef __DumpOBJ_h__
#define __DumpOBJ_h__

#include <windows.h>
#include "common.h"

//
// structures
//

//
// exported functions
//
BOOL  IsCOFFObjectImage(void* pImage);
BOOL  OBJ_DumpHeader(void* pObj);
BOOL  OBJ_DumpObjectHeaderTable(void* pObj);
BOOL  OBJ_DumpSymbolTable(void* pObj);
void  OBJ_PrintSummary(void* pObj);
BOOL  OBJ_DumpOptionalHeader(void* pObj);

//
// exported variables
//

#endif // __DumpOBJ_h__