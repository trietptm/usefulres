
#include "DumpCoffLib.h"
#include "DumpPE.h"
#include "DumpOBJ.h"
#include "PESnoop.h"

//
// prototypes
//
void  CLIB_DumpArchiveMemberHeader(PIMAGE_ARCHIVE_MEMBER_HEADER phdr);
void  CLIB_DumpImportLibraryRecord(IMPORT_OBJECT_HEADER* phdr);
void  CLIB_DumpLongNamesMember(void* p, DWORD dwc);
void  CLIB_DumpFirstLinkerMember1(void* p);
void  CLIB_DumpFirstLinkerMember2(void* p);
BOOL  CLIB_PrintLibraryImageSummary(void* pLib);

//
// constants
//
WORD_FLAG_STR_TABLE wfObjHdrTypes[] = 
{
	0, "CODE",
	1, "DATA",
	2, "CONST"
};

WORD_FLAG_STR_TABLE wfObjHdrNameTypes[] =
{
	0, "ORDINAL",
	1, "NAME",
	2, "NAME_NO_PREFIX",
	3, "NAME_UNDECORATE"
};

//
// global variables
//
char* szLongNamesBase = NULL;

BOOL CLIB_IsCoffLibraryImage(void* pImage)
{
	__try
	{
		return memcmp(pImage, IMAGE_ARCHIVE_START, IMAGE_ARCHIVE_START_SIZE) == 0 ? TRUE : FALSE;
	}
	__except(EXCEPTION_EXECUTE_HANDLER)
	{
		return FALSE; // ERR
	}
}

//
// top routine to dump libraries
//
// Args:
// dwFlags  - CMD_* (declared in PESnoop.h)
//
BOOL CLIB_DumpLibraryImage(void* pImage, DWORD dwFlags)
{
	BOOL                         bLinkerMember1Processed = FALSE;
	BOOL                         bLinkerMember2Processed = FALSE;
	IMAGE_ARCHIVE_MEMBER_HEADER  *pAMH;
	IMPORT_OBJECT_HEADER         *pOH;
	DWORD                        dwHdrSize, iHdr;
	void*                        pOBJMod;

	// get ptr to first archive member hdr
	pAMH = MakePtr(PIMAGE_ARCHIVE_MEMBER_HEADER, pImage, IMAGE_ARCHIVE_START_SIZE);

	__try
	{
		iHdr = 0;
		while (TRUE)
		{
			//
			// dump archive member hdr
			//
			if ( TESTBIT(dwFlags, CMD_LIB_AMH) )
			{
				printf("->%u.Archive Member Header (Offset: "DWMASK")\n",
					iHdr + 1, (DWORD)pAMH - (DWORD)pImage);
				CLIB_DumpArchiveMemberHeader(pAMH);
				nextline;
			}

			//
			// dump archive member hdr following structures
			//
			pOH = (IMPORT_OBJECT_HEADER*)(pAMH + 1);
			if (pOH->Sig1 == IMAGE_FILE_MACHINE_UNKNOWN
				&& pOH->Sig2 == IMPORT_OBJECT_HDR_SIG2)
			{
				// dump import library records
				if ( TESTBIT(dwFlags, CMD_LIB_ILR) )
				{
					printf("->Import Library Record\n");
                    CLIB_DumpImportLibraryRecord(pOH);
					nextline;
				}
			}
			else if (memcmp(pAMH->Name, IMAGE_ARCHIVE_LINKER_MEMBER, 16) == 0)
			{
				// dump linker members
				if (!bLinkerMember1Processed)
				{
					if ( TESTBIT(dwFlags, CMD_LIB_LM) )
					{
						printf("->First Linker Member\n");
                        CLIB_DumpFirstLinkerMember1( (void*)(pAMH + 1) );
						nextline;
					}
					bLinkerMember1Processed = TRUE; // set flag
				}
				else if (!bLinkerMember2Processed)
				{
					if ( TESTBIT(dwFlags, CMD_LIB_LM) )
					{
						printf("->Second Linker Member\n");
                        CLIB_DumpFirstLinkerMember2( (void*)(pAMH + 1) );
						nextline;
					}
					bLinkerMember2Processed = TRUE; // set flag
				}
			}
			else if (memcmp(pAMH->Name, IMAGE_ARCHIVE_LONGNAMES_MEMBER, 16) == 0)
			{
				// dump long names member
				if ( TESTBIT(dwFlags, CMD_LIB_LNM) )
				{
					printf("->Long Names Member:\n");
                    CLIB_DumpLongNamesMember(
						(void*)(pAMH + 1),
						atol((char*)&pAMH->Size));
					nextline;
				}
			}
			else
			{
				// dump as object module image part
				if ( TESTBIT(dwFlags, CMD_OBJ_ALL) )
				{
					pOBJMod = (void*)(pAMH + 1);
					printf("->Object Module Image Part:\n");
					/*
					if ( !IsCOFFObjectImage(pOBJMod) )
						printf("   Invalid Object Module !\n");
					else
					*/
					{
						if ( TESTBIT(dwFlags, CMD_OBJ_FH) )
							OBJ_DumpHeader(pOBJMod);
						if ( TESTBIT(dwFlags, CMD_OBJ_OH) )
							OBJ_DumpOptionalHeader(pOBJMod);
						if ( TESTBIT(dwFlags, CMD_OBJ_SHT) )
							OBJ_DumpObjectHeaderTable(pOBJMod);
						if ( TESTBIT(dwFlags, CMD_OBJ_ST) )
							OBJ_DumpSymbolTable(pOBJMod);
						if ( TESTBIT(dwFlags, CMD_OBJ_S) )
							OBJ_PrintSummary(pOBJMod);
					}
					//nextline;
				}
			}

			// calc ptr to next archive member hdr
			dwHdrSize = atoi((char*)pAMH->Size) + sizeof(IMAGE_ARCHIVE_MEMBER_HEADER);
			dwHdrSize = (dwHdrSize+1) & ~1; // round up
			pAMH = MakePtr(PIMAGE_ARCHIVE_MEMBER_HEADER, pAMH, dwHdrSize);
			//
			// all archive members already processed ?
			//
			__try
			{
				if (memcmp(pAMH->EndHeader, IMAGE_ARCHIVE_END, 2))
					break; // end of hdrs ! - leave while loop
			}
			__except(EXCEPTION_EXECUTE_HANDLER)
			{
				break; // leave while loop
			}
			// prepare for next hdr
			iHdr++;
			if ( TESTBIT(dwFlags, CMD_LIB_AMH) )
				printf("----------------------------------------------------------------------------\n\n");
		} // ENDOF: while (pAMH)
	}
	__except(EXCEPTION_EXECUTE_HANDLER)
	{
		nextline;
		printf("   Access violation !\n");
		nextline;
		return FALSE; // ERR
	}
	//if ( dwFlags & ~CMD_LIB_S ) // sth except the lib summary listed ?
    //    nextline;

	//
	// summary
	//
	if ( TESTBIT(dwFlags, CMD_LIB_S) )
        CLIB_PrintLibraryImageSummary(pImage);

	return TRUE; // OK
}

//
// dump IMAGE_ARCHIVE_MEMBER_HEADERs
//
void CLIB_DumpArchiveMemberHeader(PIMAGE_ARCHIVE_MEMBER_HEADER phdr)
{
	char    cDate[80], *szTDS;
	time_t  TDS;

	// name
	printf("   Name:     %.16s", phdr->Name);
	if (szLongNamesBase
		&& phdr->Name[0] == '/'
		&& isdigit(phdr->Name[1]))
		printf("  (\"%s\")", szLongNamesBase + atoi((char*)phdr->Name + 1)); // print long name
	nextline;
	// date
	wsprintf(cDate, "%.12s", phdr->Date);
	TDS = (time_t)(LONG)atol(cDate);
	szTDS = TimeDateStampToStr((DWORD)TDS);
	printf("   Date:     %.12s", phdr->Date);
	if (szTDS)
		printf("  (GMT: %s)", szTDS);
	nextline;
    // UserID
	printf("   UserID:   %.6s\n", phdr->UserID);
	// GroupID
	printf("   GroupID:  %.6s\n", phdr->GroupID);
    // Mode
	printf("   Mode:     %.8s\n", phdr->Mode);
	// Size
	printf("   Size:     %.10s  ("DWMASK")\n", phdr->Size, atol((char*)&phdr->Size));

	return;
}

//
// dump IMPORT_OBJECT_HEADERs
//
void CLIB_DumpImportLibraryRecord(IMPORT_OBJECT_HEADER* phdr)
{
	char*  szTDS, *szDll, *szSym;
	UINT   i;

	// version
	printf("   Version:        "WMASK"\n", phdr->Version);
	// machine
	printf("   Machine:        "WMASK, phdr->Machine);
	for (i = 0; i < ARRAY_ITEMS(PEMachine); i++)
		if (PEMachine[i].wFlag == phdr->Machine)
		{
			printf("  (%s)", PEMachine[i].szFlag);
			break;
		}
	nextline;
	// timedatestamp
	printf("   TimeDateStamp:  "DWMASK, phdr->TimeDateStamp);
	szTDS = TimeDateStampToStr(phdr->TimeDateStamp);
	if (szTDS)
		printf("  (%s)", szTDS);
	nextline;
	// size
	printf("   SizeOfData:     "DWMASK"\n", phdr->SizeOfData);
	// hint/ordinal
	if (phdr->NameType & IMPORT_OBJECT_ORDINAL)
		printf("   Ordinal:        "WMASK"\n", phdr->Ordinal);
	else
		printf("   Hint:           "WMASK"\n", phdr->Hint);
	// type
	printf("   Type:           "WMASK, phdr->Type);
	for (i = 0; i < ARRAY_ITEMS(wfObjHdrTypes); i++)
		if (wfObjHdrTypes[i].wFlag == phdr->Type)
		{
			printf("  (%s)", wfObjHdrTypes[i].szFlag);
			break;
		}
	nextline;
	// name type
	printf("   NameType:       "WMASK, phdr->NameType);
	for (i = 0; i < ARRAY_ITEMS(wfObjHdrNameTypes); i++)
		if (wfObjHdrNameTypes[i].wFlag == phdr->NameType)
		{
			printf("  (%s)", wfObjHdrNameTypes[i].szFlag);
			break;
		}
	nextline;
	// reserved
	printf("   Reserved:       "WMASK"\n", phdr->Reserved);
	// symbol/dll name
	szSym = (char*)(phdr + 1);
	szDll = MakePtr(PSTR, szSym, lstrlen(szSym) + 1);
	printf("   Symbol:         \"%s\"\n", szSym);
	printf("   Dll:            \"%s\"\n", szDll);

	return;
}

void CLIB_DumpLongNamesMember(void* p, DWORD dwc)
{
	DWORD dwStrLen, dwOff = 0;
	char* szStr = (char*)p;

	szLongNamesBase = (char*)p; // save for later use while dumping archive member hdrs

	if (!dwc)
		return;
	// print grid hdr
	printf("   Offset     String\n");
	printf("   ---------- ----------\n");
	while (dwOff < dwc)
	{
		dwStrLen = lstrlen(szStr) + 1;
		printf("   "DWMASK" \"%s\"\n", dwOff, szStr);
		szStr += dwStrLen;
		dwOff += dwStrLen;
	}

	return;
}

void CLIB_DumpFirstLinkerMember1(void* p)
{
	DWORD  dwcSyms, *pdwMemberOff;
	char*  szSymName;
	UINT   i;
	
	pdwMemberOff = MakePtr(PDWORD, p, 4);
	// obtain symbol count + symbol names base
	dwcSyms   = EndianSwitch(*(PDWORD)p);
	szSymName  = (char*)(dwcSyms * 4 + (DWORD)pdwMemberOff);

	//
	// list member off + name
	//

	//print grid hdr
	nextline;
	printf("   Member Offset Symbol Name\n");
	printf("   ------------- -------------------\n");
	// go go go...
    for (i = 0; i < dwcSyms; i++)
	{
		printf(
			"   "DWMASK"    \"%s\"\n",
			EndianSwitch(*pdwMemberOff),
			szSymName);
		// prepare for next member
		pdwMemberOff++;
		szSymName += lstrlen((char*)szSymName) + 1;
	}
	nextline;
	printf("   (Symbol Count:          "DWMASK")\n", dwcSyms);

	return;
}

//
// nearly the same structure as the first linker member but with slight but important changes
//
void CLIB_DumpFirstLinkerMember2(void* p)
{
	DWORD  dwcArchiveMembers, dwcSyms, *pdwMemberOff;
	WORD   *pwIndices;
	char*  szSymName;
	UINT   i;
	
	// obtain archive member/symbol count + symbol names base
	//dwcArchiveMembers = EndianSwitch(*(PDWORD)p);
	dwcArchiveMembers = *(PDWORD)p;
	pdwMemberOff      = MakePtr(PDWORD, p, 4);
	dwcSyms           = pdwMemberOff[dwcArchiveMembers];
	pwIndices         = MakePtr(PWORD, p, 4 + dwcArchiveMembers * sizeof(DWORD) + 4 );
	szSymName         = (char*)(dwcSyms * sizeof(WORD) + (DWORD)pwIndices);

	//
	// list member off + name
	//

	//print grid hdr
	nextline;
	printf("   Index  Member Offset Symbol Name\n");
	printf("   ------ ------------- ---------------------------------\n");
	// go go go...
    for (i = 0; i < dwcSyms; i++)
	{
		printf(
			"   "WMASK" "DWMASK"    \"%s\"\n",
			pwIndices[i],
			pdwMemberOff[pwIndices[i] - 1],
			szSymName);
		// prepare for next member
		szSymName += lstrlen((char*)szSymName) + 1;
	}
	nextline;
	printf("   (Symbol Count:          "DWMASK")\n", dwcSyms);
	printf("   (Archive Member Count:  "DWMASK")\n", dwcArchiveMembers);

	return;
}

//
// currently lists only the exports
//
BOOL CLIB_PrintLibraryImageSummary(void* pLib)
{
	IMAGE_ARCHIVE_MEMBER_HEADER  *pAMH;
	IMPORT_OBJECT_HEADER         *pOH;
	DWORD                        dwHdrSize, iHdr, icExpSyms;
	char*                        szSym;

	// title
	printf("->Library Image Summary\n");
	// get ptr to first archive member hdr
	pAMH = MakePtr(PIMAGE_ARCHIVE_MEMBER_HEADER, pLib, IMAGE_ARCHIVE_START_SIZE);

	__try
	{
		icExpSyms = iHdr = 0;
		while (TRUE)
		{
			//
			// process import library records
			//
			pOH = (IMPORT_OBJECT_HEADER*)(pAMH + 1);
			if (pOH->Sig1 == IMAGE_FILE_MACHINE_UNKNOWN
				&& pOH->Sig2 == IMPORT_OBJECT_HDR_SIG2)
			{
				if (!icExpSyms)
				{
					// print grid hdr
					nextline;
					printf("   Ordinal/Hint Symbol Name\n");
					printf("   ------------ -----------------------------------------\n");
				}
				szSym = (char*)(pOH + 1);
				printf("   "WMASK, pOH->Hint);
				if ( !(pOH->NameType & IMPORT_OBJECT_ORDINAL) )
					printf("       \"%s\"", szSym);
                nextline;
				icExpSyms++;
			}

			// calc ptr to next archive member hdr
			dwHdrSize = atoi((char*)pAMH->Size) + sizeof(IMAGE_ARCHIVE_MEMBER_HEADER);
			dwHdrSize = (dwHdrSize+1) & ~1; // round up
			pAMH = MakePtr(PIMAGE_ARCHIVE_MEMBER_HEADER, pAMH, dwHdrSize);
			//
			// all archive members already processed ?
			//
			__try
			{
				if (memcmp(pAMH->EndHeader, IMAGE_ARCHIVE_END, 2))
					break; // end of hdrs ! - leave while loop
			}
			__except(EXCEPTION_EXECUTE_HANDLER)
			{
				break; // leave while loop
			}
			// prepare for next hdr
			iHdr++;
		} // ENDOF: while (pAMH)
	}
	__except(EXCEPTION_EXECUTE_HANDLER)
	{
		nextline;
		printf("   Access violation !\n");
		nextline;
		return FALSE; // ERR
	}
	nextline;
	printf("   (Exported Symbols:  "DWMASK")\n", icExpSyms);
	nextline;

	return TRUE;
}