
#include "DumpPE.h"
#include "PESnoop.h"

//
// structures
//

//
// prototypes
//
BOOL                      PE_IsPE64(PIMAGE_NT_HEADERS pNT);
template <class T> BOOL   PE_DumpNtHeaders3264(T* pNT);
PIMAGE_SECTION_HEADER     PE_RvaToSection(PIMAGE_NT_HEADERS pNT, DWORD dwRVA);
PIMAGE_SECTION_HEADER     PE_RvaToSection(PIMAGE_FILE_HEADER pFH, DWORD dwRVA);
void*                     PE_RvaToPtr(PIMAGE_NT_HEADERS pNT, DWORD dwRVA);
void*                     PE_VaToPtr(DWORD dwVA);
BOOL                      ExtractSectionName(IN PIMAGE_SECTION_HEADER pSH, OUT char *pszBuff, IN DWORD dwBuffSize);
void*                     PE_GetDirectoryEntryPtr(PIMAGE_NT_HEADERS pNT, DWORD iDir);
PIMAGE_DATA_DIRECTORY     PE_GetDirectoryPtr(PIMAGE_NT_HEADERS pNT, DWORD iDir);
DWORD                     PE_GetDirectoryCount(PIMAGE_NT_HEADERS pNT);
DWORD                     PE_GetDirectoryCount(DWORD dwOptHdrSize, BOOL b64Bit);
char*                     TimeDateStampToStr(DWORD dwTDS);
DWORD                     PE_CalcRealHeaderSize(PIMAGE_NT_HEADERS pNT);
void                      HexDump(void* pData, DWORD dwStartOff, DWORD dwBytes);
BOOL                      ResUStr2ASCII(PIMAGE_RESOURCE_DIR_STRING_U pIRDS, char* pszBuff, DWORD dwc);
void                      PE_ProcessResourceDirectory(DWORD dwLevel, BOOL bDetails,
													  PIMAGE_RESOURCE_DIRECTORY pRootIRD,
                                                      PIMAGE_RESOURCE_DIRECTORY prdToDump);
void                      PE_ProcessResourceEntry(DWORD dwLevel, BOOL bDetails,
												  PIMAGE_RESOURCE_DIRECTORY pRootIRD,
												  PIMAGE_RESOURCE_DIRECTORY_ENTRY preToDump);
//
// constants/macros
//
#define asctime_MAX_CHARS            26

#define IMAGE_RESOURCE_GET_DIR_ENTRY(DirBase) (IMAGE_RESOURCE_DIRECTORY_ENTRY*)((DWORD)DirBase + \
	sizeof(IMAGE_RESOURCE_DIRECTORY))

WORD_FLAG_STR_TABLE PEMachine[29] =
{
	0, "UNKNOWN",
	0x014c, "I386",
	0x0162, "R3000",
	0x0166, "R4000",
	0x0168, "R10000",
	0x0169, "WCEMIPSV2",
	0x0184, "ALPHA",
	0x01a2, "SH3",
	0x01a3, "SH3DSP",
	0x01a4, "SH3E",
	0x01a6, "SH4",
	0x01a8, "SH5",
	0x01c0, "ARM",
	0x01c2, "THUMB",
	0x01d3, "AM33",
	0x01F0, "POWERPC",
	0x01F1, "POWERPCFP",
	0x0200, "IA64",
	0x0266, "MIPS16",
	0x0284, "ALPHA64",
	0x0366, "MIPSFPU",
	0x0466, "MIPSFPU16",
	0x0284, "ALPHA64/AXP64",
	0x0520, "TRICORE",
	0x8664, "AMD64",
	0x9041, "M32R",
	0x0EBC, "EBC",
	0x0CEF, "CEF",
	0xC0EE, "CEE"
};

WORD_FLAG_STR_TABLE PECharacteristics[] =
{
	0x0001, "RELOCS_STRIPPED",
	0x0002, "EXECUTABLE_IMAGE",
	0x0004, "LINE_NUMS_STRIPPED",
	0x0008, "LOCAL_SYMS_STRIPPED",
	0x0010, "AGGRESIVE_WS_TRIM",
	0x0020, "LARGE_ADDRESS_AWARE",
	0x0080, "BYTES_REVERSED_LO",
	0x0100, "32BIT_MACHINE",
	0x0200, "DEBUG_STRIPPED",
	0x0400, "REMOVABLE_RUN_FROM_SWAP",
	0x0800, "NET_RUN_FROM_SWAP",
	0x1000, "SYSTEM",
	0x2000, "DLL",
	0x4000, "UP_SYSTEM_ONLY",
	0x8000, "BYTES_REVERSED_HI" 
};

WORD_FLAG_STR_TABLE PEMagic[] =
{
	0x10b, "HDR32_MAGIC",
	0x20b, "HDR64_MAGIC",
	0x107, "IMAGE_ROM_OPTIONAL_HDR_MAGIC"
};

WORD_FLAG_STR_TABLE PESubsystem[] =
{
	0, "UNKNOWN",
	1, "NATIVE",
	2, "WINDOWS_GUI",
	3, "WINDOWS_CUI",
	5, "OS2_CUI",
	7, "POSIX_CUI",
	8, "NATIVE_WINDOWS",
	9, "WINDOWS_CE_GUI",
	10, "EFI_APPLICATION",
	11, "EFI_BOOT_SERVICE_DRIVER",
	12, "EFI_RUNTIME_DRIVER",
	13, "EFI_ROM",
	14, "XBOX"
};

WORD_FLAG_STR_TABLE PEDllCharacteristics[] =
{
	0x0800, "NO_BIND",
	0x2000, "WDM_DRIVER",
	0x8000, "TERMINAL_SERVER_AWARE"
};

const char* szDataDirectory[] =
{
	"ExportTable",
    "ImportTable",
	"Resource",
	"Exception",
	"Security",
	"Relocation",
	"Debug",
	"Copyright",
	"GlobalPtr",
	"TLSTable",
	"LoadConfig",
	"BoundImport",
	"IAT",
	"DelayImport",
	"COM",
};

DWORD_FLAG_STR_TABLE PESectionFlags[] =
{
//	0x00000000, "REG",
	0x00000001, "DSECT",
	0x00000002, "NOLOAD",
	0x00000004, "GROUP",
	0x00000008, "NO_PAD",
	0x00000010, "COPY",
	0x00000020, "CODE",
	0x00000040, "INITIALIZED_DATA",
	0x00000080, "UNINITIALIZED_DATA",
	0x00000100, "OTHER",
	0x00000200, "INFO",
	0x00000400, "OVER",
	0x00000800, "REMOVE",
	0x00001000, "COMDAT",
	0x00004000, "NO_DEFER_SPEC_EXC",
	0x00008000, "FARDATA",
	0x00010000, "SYSHEAP",
	0x00020000, "16BIT",
	0x00040000, "LOCKED",
	0x00080000, "PRELOAD",
	0x01000000, "NRELOC_OVFL",
	0x02000000, "DISCARDABLE",
	0x04000000, "NOT_CACHED",
	0x08000000, "NOT_PAGED",
	0x10000000, "SHARED",
	0x20000000, "EXECUTE",
	0x40000000, "READ",
	0x80000000, "WRITE"
};

DWORD_FLAG_STR_TABLE PESectionAlignFlags[] =
{
	0x00100000, "ALIGN_1BYTES",
	0x00200000, "ALIGN_2BYTES",
	0x00300000, "ALIGN_4BYTES",
	0x00400000, "ALIGN_8BYTES",
	0x00500000, "ALIGN_16BYTES",
	0x00600000, "ALIGN_32BYTES",
	0x00700000, "ALIGN_64BYTES",
	0x00800000, "ALIGN_128BYTES",
	0x00900000, "ALIGN_256BYTES",
	0x00A00000, "ALIGN_512BYTES",
	0x00B00000, "ALIGN_1024BYTES",
	0x00C00000, "ALIGN_2048BYTES",
	0x00D00000, "ALIGN_4096BYTES",
	0x00E00000, "ALIGN_8192BYTES"
};

DWORD_FLAG_STR_TABLE PEDebugTypes[] =
{
	0, "UNKNOWN",
	1, "COFF",
	2, "CODEVIEW",
	3, "FPO",
	4, "MISC",
	5, "EXCEPTION",
	6, "FIXUP",
	7, "OMAP_TO_SRC",
	8, "OMAP_FROM_SRC",
	9, "BORLAND",
	10, "RESERVED10",
	11, "CLSID"
};

BYTE_FLAG_STR_TABLE PERelocationTypes[] =
{
	0, "ABSOLUTE",
	1, "HIGH",
	2, "LOW",
	3, "HIGHLOW",
	4, "HIGHADJ",
	5, "MIPS_JMPADDR",
	9, "MIPS_JMPADDR16/IA64_IMM64",
	10, "DIR64"
};

const char* szCOMDirectory[] =
{
	"MetaData",
	"Resources",
	"StrongNameSignature",
	"CodeManagerTable",
	"VTableFixups",
	"ExportAddressTableJumps",
	"ManagedNativeHeader"
};

DWORD_FLAG_STR_TABLE PEComEntryPointFlags[] =
{
	0x00000001, "ILONLY",
	0x00000002, "32BITREQUIRED",
	0x00000004, "IL_LIBRARY",
	0x00010000, "TRACKDEBUGDATA"
};

const char* szResourceTypes[] =
{
	"0x0000",                     // ?
	"CURSOR",
	"BITMAP",
	"ICON",
	"MENU",
	"DIALOG",                     // 5
	"STRING TABLE",
	"FONT DIRECTORY",
	"FONT",
	"ACCELERATORS",
	"UNFORMATTED RESOURCE DATA",  // 10
	"MESSAGE TABLE",
	"GROUP CURSOR",
	"0x0013",                     // ?
	"GROUP ICON",
	"0x0015",                     // ?
	"VERSION INFORMATION"
};

//
// global variables
//
BOOL PE_IsPE64(IMAGE_DOS_HEADER *pdh)
{
	IMAGE_NT_HEADERS *pnt;

	pnt = MakePtr(PIMAGE_NT_HEADERS, pdh, pdh->e_lfanew);
	return pnt->OptionalHeader.Magic == IMAGE_NT_OPTIONAL_HDR64_MAGIC ? TRUE : FALSE;
}

//
// overloaded
//
BOOL PE_IsPE64(PIMAGE_NT_HEADERS pNT)
{
	return pNT->OptionalHeader.Magic == IMAGE_NT_OPTIONAL_HDR64_MAGIC ? TRUE : FALSE;
}

//
// overloaded
//
BOOL PE_IsPE64(PIMAGE_OPTIONAL_HEADER pOH)
{
	return pOH->Magic == IMAGE_NT_OPTIONAL_HDR64_MAGIC ? TRUE : FALSE;
}

//
// Notes:
// Fails for RVAs pointing into the PE Header
//
// Returns:
// NULL     - in case of an error
//
PIMAGE_SECTION_HEADER PE_RvaToSection(PIMAGE_NT_HEADERS pNT, DWORD dwRVA)
{
	return ImageRvaToSection(
		pNT,
		PE.pImage,
		dwRVA);
}

//
// overloaded
//
PIMAGE_SECTION_HEADER PE_RvaToSection(PIMAGE_FILE_HEADER pFH, DWORD dwRVA)
{
	UINT                  u;
	IMAGE_SECTION_HEADER  *pSH;

	pSH = (PIMAGE_SECTION_HEADER)((DWORD)(pFH + 1) + pFH->SizeOfOptionalHeader);
	for (u = 0; u < pFH->NumberOfSections; u++)
	{
		if (dwRVA >= pSH->VirtualAddress
			&& dwRVA < pSH->VirtualAddress + pSH->Misc.VirtualSize)
			return pSH; // OK
		++pSH; // next sec hdr
	}

	return NULL; // ERR
}

void* PE_RvaToPtr(PIMAGE_NT_HEADERS pNT, DWORD dwRVA)
{
	return ImageRvaToVa(
		pNT,
		PE.pImage,
		dwRVA,
		NULL);
}

void* PE_VaToPtr(DWORD dwVA)
{
	if ( PE.b64Bit )
		return PE_RvaToPtr(PE.pNT, (DWORD)(dwVA - PE.pNT64->OptionalHeader.ImageBase));
	else
		return PE_RvaToPtr(PE.pNT, dwVA - PE.pNT->OptionalHeader.ImageBase);
}

BOOL ExtractSectionName(IN PIMAGE_SECTION_HEADER pSH, OUT char *pszBuff, IN DWORD dwBuffSize)
{
	if (!pSH)
		return FALSE; // ERR
	if (dwBuffSize < 9)
		return FALSE; // ERR

	memset((void*)pszBuff, 0, 9);
	memcpy(
		(void*)pszBuff,
		pSH->Name,
		8);

	return TRUE; // OK
}

void* PE_GetDirectoryEntryPtr(PIMAGE_NT_HEADERS pNT, DWORD iDir)
{
	DWORD dwRva;

	// dir specified in PE ?
	if (iDir >= PE_GetDirectoryCount(pNT))
		return NULL; // ERR

	// dir present ?
	if ( PE_IsPE64(pNT) )
		dwRva = ((PIMAGE_NT_HEADERS64)pNT)->OptionalHeader.DataDirectory[iDir].VirtualAddress;
	else
		dwRva = ((PIMAGE_NT_HEADERS32)pNT)->OptionalHeader.DataDirectory[iDir].VirtualAddress;
	if (!dwRva)
		return NULL; // ERR

	// ret ptr
	return PE_RvaToPtr(pNT, dwRva);
}

//
// Returns:
// NULL     - in case of an error
//
PIMAGE_DATA_DIRECTORY PE_GetDirectoryPtr(PIMAGE_NT_HEADERS pNT, DWORD iDir)
{
	// dir specified in PE ?
	if (iDir >= PE_GetDirectoryCount(pNT))
		return NULL; // ERR

	// dir present ?
	if ( PE_IsPE64(pNT) )
		return &((PIMAGE_NT_HEADERS64)pNT)->OptionalHeader.DataDirectory[iDir];
	else
		return &((PIMAGE_NT_HEADERS32)pNT)->OptionalHeader.DataDirectory[iDir];
}

DWORD PE_GetDirectoryCount(PIMAGE_NT_HEADERS pNT)
{
	if ( PE_IsPE64(pNT) )
		return (pNT->FileHeader.SizeOfOptionalHeader - offsetof(IMAGE_OPTIONAL_HEADER64, DataDirectory)) /
			sizeof(IMAGE_DATA_DIRECTORY);
	else
		return (pNT->FileHeader.SizeOfOptionalHeader - offsetof(IMAGE_OPTIONAL_HEADER32, DataDirectory)) /
			sizeof(IMAGE_DATA_DIRECTORY);
}

//
// overloaded
//
DWORD PE_GetDirectoryCount(DWORD dwOptHdrSize, BOOL b64Bit)
{
	if ( b64Bit )
		return (dwOptHdrSize - offsetof(IMAGE_OPTIONAL_HEADER64, DataDirectory)) /
			sizeof(IMAGE_DATA_DIRECTORY);
	else
		return (dwOptHdrSize - offsetof(IMAGE_OPTIONAL_HEADER32, DataDirectory)) /
			sizeof(IMAGE_DATA_DIRECTORY);
}

//
// Returns:
// NULL     - in case of an error
//
char* TimeDateStampToStr(DWORD dwTDS)
{
	struct tm  *pt;
	char*      sz;

	pt = gmtime((const time_t *)&dwTDS);
	if (!pt)
		return NULL; // ERR
	sz = asctime((const tm*)pt);
	__try
	{
		WipeCarriageReturn(sz);
	}
	__except(EXCEPTION_EXECUTE_HANDLER)
	{
		return NULL; // ERR
	}

    return sz; // OK
}

DWORD PE_CalcRealHeaderSize(PIMAGE_NT_HEADERS pNT)
{
	DWORD                  dwHSize;
	UINT                   i;
	IMAGE_SECTION_HEADER   *pS;

	if (!pNT->FileHeader.NumberOfSections)
		if ( PE_IsPE64(pNT) )
			return ((PIMAGE_NT_HEADERS64)pNT)->OptionalHeader.SizeOfHeaders;
		else
            return ((PIMAGE_NT_HEADERS32)pNT)->OptionalHeader.SizeOfHeaders;

	// find real size of headers my finding the lowest RO
	dwHSize = 0xFFFFFFFF;
	pS = IMAGE_FIRST_SECTION(pNT);
	for (i = 0; i < pNT->FileHeader.NumberOfSections; i++)
	{
		if (pS->PointerToRawData) // Watcom C/C++ hits an other time :)
			dwHSize = __min(dwHSize, pS->PointerToRawData);
		++pS;
	}

	return dwHSize;
}

//
// print a memory block to stdout (16 char per line)
//
// Args:
// dwStartOff - added to each printed offset at the start of the line
//
void HexDump(void* pData, DWORD dwStartOff, DWORD dwBytes)
{
	PBYTE  pbyCur;
	DWORD  dwBytesToDo = dwBytes, dwcCharsOnLine, dwIndex, i;
	char   cHexOut[80];

	if (!dwBytes)
		return; // ERR

	dwIndex = 0;
	pbyCur = (PBYTE)pData;
	while (dwBytesToDo)
	{
		//memset(&cHexOut, 0x88, sizeof(cHexOut));
		dwcCharsOnLine = __min(dwBytesToDo, 16);
		wsprintf(cHexOut, "%08lX:", dwStartOff + dwIndex);
		for (i = 0; i < 16; i++)
		{
			if (i < dwcCharsOnLine) // out of range ?
			{
                wsprintf(
					(char*)((DWORD)&cHexOut + 9 + i*3 + (DWORD)(i < 8 ? 0 : 1)),
					" %02lX",
					*pbyCur);
				cHexOut[9 + 16*3 + 3 + i] = isprint(*pbyCur) ? *pbyCur : '.';
			}
			else
			{
				lstrcpy(
					(char*)((DWORD)&cHexOut + 9 + i*3 + (DWORD)(i < 8 ? 0 : 1)),
					"   ");
				cHexOut[9 + 16*3 + 3 + i] = ' ';
			}
			++pbyCur; // next byte
		}
		// insert missing spaces + cr
		cHexOut[9 + 8*3]       = 0x20; // space between first and second 8 hex pairs
		cHexOut[9 + 16*3 + 1]  = 0x20;
		cHexOut[9 + 16*3 + 2]  = 0x20;
		cHexOut[9 + 16*3 + 3 + 16] = 0;
		// print line via 'puts' (maybe there're '%' in the string)
		puts( (const char*)cHexOut );
		// prepare vars for next line
		dwBytesToDo -= dwcCharsOnLine;
		dwIndex += 16;
	}	

	return;
}

//
// convert a IMAGE_RESOURCE_DIR_STRING_U formated string into an ASCII string
//
BOOL ResUStr2ASCII(PIMAGE_RESOURCE_DIR_STRING_U pIRDS, char* pszBuff, DWORD dwc)
{
	// buffer enough sized ?
	if (dwc < (DWORD)(pIRDS->Length / 2))
		return FALSE; // ERR

	return WideToSingleCharStrN(pIRDS->NameString, pIRDS->Length, pszBuff, dwc);
}

//
// START OF STRUCTURE DUMPER ROUTINES
//

BOOL PE_DumpDosHeader(void* pImage)
{
	IMAGE_DOS_HEADER  *pDH;
	UINT              u;

	// print title
	printf("->DOS Header\n");

	// MZ check
	pDH = (PIMAGE_DOS_HEADER)pImage;
	if (pDH->e_magic != IMAGE_DOS_SIGNATURE)
		return FALSE; // ERR

	// print items
	printf("   e_magic:     0x%04lX\n", pDH->e_magic);
	printf("   e_cblp:      0x%04lX\n", pDH->e_cblp);
	printf("   e_cp:        0x%04lX\n", pDH->e_cp);
	printf("   e_crlc:      0x%04lX\n", pDH->e_crlc);
	printf("   e_cparhdr:   0x%04lX\n", pDH->e_cparhdr);
	printf("   e_minalloc:  0x%04lX\n", pDH->e_minalloc);
	printf("   e_maxalloc:  0x%04lX\n", pDH->e_maxalloc);
	printf("   e_ss:        0x%04lX\n", pDH->e_ss);
	printf("   e_sp:        0x%04lX\n", pDH->e_sp);
	printf("   e_csum:      0x%04lX\n", pDH->e_csum);
	printf("   e_ip:        0x%04lX\n", pDH->e_ip);
	printf("   e_cs:        0x%04lX\n", pDH->e_cs);
	printf("   e_lfarlc:    0x%04lX\n", pDH->e_lfarlc);
	printf("   e_ovno:      0x%04lX\n", pDH->e_ovno);
	printf("   e_res:       0x");
	for (u = 0; u < 4; u++)
		printf("%04lX", pDH->e_res[u]);
	newline
	printf("   e_oemid:     0x%04lX\n", pDH->e_oemid);
	printf("   e_oeminfo:   0x%04lX\n", pDH->e_oeminfo);
	printf("   e_res2:      0x");
	for (u = 0; u < 10; u++)
		printf("%04lX", pDH->e_res2[u]);
	newline
	printf("   e_lfanew:    0x%08lX\n", pDH->e_lfanew);

	newline

	return TRUE; // OK
}

BOOL PE_DumpNtHeaders(PPE_HINTS pPE)
{
	if (pPE->b64Bit)
		return PE_DumpNtHeaders3264(pPE->pNT64);
	else
		return PE_DumpNtHeaders3264(pPE->pNT);
}

//
// the FileHeader is dumped in a separate routine because it's also a part of OBJs, LIBs,...
//
void PE_DumpFileHeader(PIMAGE_FILE_HEADER pFH)
{
	char  *pch;
	UINT  u;

	printf("->File Header\n");
	printf("   Machine:               0x%04lX", pFH->Machine);
	for (u = 0; u < ARRAY_ITEMS(PEMachine); u++)
		if (pFH->Machine == PEMachine[u].wFlag)
		{
			printf("  (%s)", PEMachine[u].szFlag);
			break;
		}
	newline
	printf("   NumberOfSections:      0x%04lX\n", pFH->NumberOfSections);
	printf("   TimeDateStamp:         0x%08lX",
		pFH->TimeDateStamp);
	pch = TimeDateStampToStr(pFH->TimeDateStamp);
	if (pch)
		printf("  (GMT: %s)", pch);
	newline
	printf("   PointerToSymbolTable:  0x%08lX\n", pFH->PointerToSymbolTable);
	printf("   NumberOfSymbols:       0x%08lX\n", pFH->NumberOfSymbols);
	printf("   SizeOfOptionalHeader:  0x%04lX\n", pFH->SizeOfOptionalHeader);
	printf("   Characteristics:       0x%04lX\n", pFH->Characteristics);
	for (u = 0; u < ARRAY_ITEMS(PECharacteristics); u++)
		if ( TESTBIT(PECharacteristics[u].wFlag, pFH->Characteristics) )
			printf("                          (%s)\n", PECharacteristics[u].szFlag);
	newline

	return;
}

//
// needed elsewhere to dump object module parts
//
// (PE32/PE32+ dependent)
//
void PE_DumpOptionalHeader(PIMAGE_OPTIONAL_HEADER pIOH, PIMAGE_FILE_HEADER pFH)
{
	UINT                  u, ucDirs;
	char                  cSec[9], *pch;
	IMAGE_SECTION_HEADER  *pSH;
	BOOL                  b64Bit = PE_IsPE64(pIOH);

	// print title
	printf("->Optional Header");
	if (b64Bit)
		printf(" 64");
	newline

	// present ?
	if (!pFH->SizeOfOptionalHeader)
	{
		printf("   Not present !\n\n");
		return;
	}

	// print items being equal in IMAGE_OPTIONAL_HEADER and IMAGE_OPTIONAL_HEADER64
	printf("   Magic:                        "WMASK, pIOH->Magic);
	for (u = 0; u < ARRAY_ITEMS(PEMagic); u++)
		if (pIOH->Magic == PEMagic[u].wFlag)
		{
			printf("  (%s)", PEMagic[u].szFlag);
			break;
		}
	newline
	printf("   MajorLinkerVersion:           "BMASK"\n", pIOH->MajorLinkerVersion);
	printf("   MinorLinkerVersion:           "BMASK"  -> ", pIOH->MinorLinkerVersion);
	printf(
		"%u.%02u\n",
		pIOH->MajorLinkerVersion,
		pIOH->MinorLinkerVersion);
	printf("   SizeOfCode:                   "DWMASK"\n", pIOH->SizeOfCode);
	printf("   SizeOfInitializedData:        "DWMASK"\n", pIOH->SizeOfInitializedData);
	printf("   SizeOfUninitializedData:      "DWMASK"\n", pIOH->SizeOfUninitializedData);
	printf("   AddressOfEntryPoint:          "DWMASK"\n", pIOH->AddressOfEntryPoint);
	printf("   BaseOfCode:                   "DWMASK"\n", pIOH->BaseOfCode);

	// print PE32/PE32+ depended items
	if (b64Bit)
		printf("   ImageBase:                    "QWMASK"\n",
			((PIMAGE_OPTIONAL_HEADER64)pIOH)->ImageBase);
	else
	{
		printf("   BaseOfData:                   "DWMASK"\n",
			((PIMAGE_OPTIONAL_HEADER32)pIOH)->BaseOfData);
		printf("   ImageBase:                    "DWMASK"\n",
			((PIMAGE_OPTIONAL_HEADER32)pIOH)->ImageBase);
	}

	// continue with independent items
	printf("   SectionAlignment:             "DWMASK"\n", pIOH->SectionAlignment);
	printf("   FileAlignment:                "DWMASK"\n", pIOH->FileAlignment);
	printf("   MajorOperatingSystemVersion:  "WMASK"\n", pIOH->MajorOperatingSystemVersion);
	printf("   MinorOperatingSystemVersion:  "WMASK"  -> ", pIOH->MinorOperatingSystemVersion);
	printf(
		"%u.%02u\n", 
		pIOH->MajorOperatingSystemVersion,
		pIOH->MinorOperatingSystemVersion);
	printf("   MajorImageVersion:            "WMASK"\n", pIOH->MajorImageVersion);
	printf("   MinorImageVersion:            "WMASK"  -> ", pIOH->MinorImageVersion);
	printf(
		"%u.%02u\n",
		pIOH->MajorImageVersion,
		pIOH->MinorImageVersion);
	printf("   MajorSubsystemVersion:        "WMASK"\n", pIOH->MajorSubsystemVersion);
	printf("   MinorSubsystemVersion:        "WMASK"  -> ", pIOH->MinorSubsystemVersion);
	printf(
		"%u.%02u\n",
		pIOH->MajorSubsystemVersion,
		pIOH->MinorSubsystemVersion);
	printf("   Win32VersionValue:            "DWMASK"\n", pIOH->Win32VersionValue);
	printf("   SizeOfImage:                  "DWMASK"\n", pIOH->SizeOfImage);
	printf("   SizeOfHeaders:                "DWMASK"\n", pIOH->SizeOfHeaders);
	printf("   CheckSum:                     "DWMASK"\n", pIOH->CheckSum);
	printf("   Subsystem:                    "WMASK, pIOH->Subsystem);
	for (u = 0; u < ARRAY_ITEMS(PESubsystem); u++)
		if (PESubsystem[u].wFlag == pIOH->Subsystem)
		{
			printf("  (%s)\n", PESubsystem[u].szFlag);
			break;
		}
	printf("   DllCharacteristics:           "WMASK, pIOH->DllCharacteristics);
	for (u = 0; u < ARRAY_ITEMS(PEDllCharacteristics); u++)
		if (PEDllCharacteristics[u].wFlag == pIOH->DllCharacteristics)
		{
			printf("  (%s)", PEDllCharacteristics[u].szFlag);
			break;
		}
	newline

	// handle 32/64 bit dependent code items
	if (b64Bit)
	{
		printf(
			"   SizeOfStackReserve:           "QWMASK"\n",
			((PIMAGE_OPTIONAL_HEADER64)pIOH)->SizeOfStackReserve);
		printf(
			"   SizeOfStackCommit:            "QWMASK"\n",
			((PIMAGE_OPTIONAL_HEADER64)pIOH)->SizeOfStackCommit);
		printf(
			"   SizeOfHeapReserve:            "QWMASK"\n",
			((PIMAGE_OPTIONAL_HEADER64)pIOH)->SizeOfHeapReserve);
		printf(
			"   SizeOfHeapCommit:             "QWMASK"\n",
			((PIMAGE_OPTIONAL_HEADER64)pIOH)->SizeOfHeapCommit);
		printf("   LoaderFlags:                  "DWMASK"\n",
			((PIMAGE_OPTIONAL_HEADER64)pIOH)->LoaderFlags);
		printf("   NumberOfRvaAndSizes:          "DWMASK"\n",
			((PIMAGE_OPTIONAL_HEADER64)pIOH)->NumberOfRvaAndSizes);

		newline
	}
	else
	{
		printf(
			"   SizeOfStackReserve:           "DWMASK"\n",
			((PIMAGE_OPTIONAL_HEADER32)pIOH)->SizeOfStackReserve);
		printf(
			"   SizeOfStackCommit:            "DWMASK"\n",
			((PIMAGE_OPTIONAL_HEADER32)pIOH)->SizeOfStackCommit);
		printf(
			"   SizeOfHeapReserve:            "DWMASK"\n",
			((PIMAGE_OPTIONAL_HEADER32)pIOH)->SizeOfHeapReserve);
		printf(
			"   SizeOfHeapCommit:             "DWMASK"\n",
			((PIMAGE_OPTIONAL_HEADER32)pIOH)->SizeOfHeapCommit);
		printf("   LoaderFlags:                  "DWMASK"\n",
			((PIMAGE_OPTIONAL_HEADER32)pIOH)->LoaderFlags);
		printf("   NumberOfRvaAndSizes:          "DWMASK"\n",
			((PIMAGE_OPTIONAL_HEADER32)pIOH)->NumberOfRvaAndSizes);

		newline
	}

	//
	// dump DataDirectory chain
	//
	ucDirs = PE_GetDirectoryCount(pFH->SizeOfOptionalHeader, b64Bit);

	printf("   DataDirectory (%02u)            RVA        Size\n", ucDirs);
	printf("   -------------                 ---------- ----------\n");
    for (u = 0; u < ucDirs; u++)
	{
		// print name, RVA, size
        if (u < ARRAY_ITEMS(szDataDirectory))
			pch = (char*)szDataDirectory[u];
		else
			pch = "Reserved";
		if (b64Bit)
			printf(
				"   %-30s"DWMASK" "DWMASK,
				pch,
				((PIMAGE_OPTIONAL_HEADER64)pIOH)->DataDirectory[u].VirtualAddress,
				((PIMAGE_OPTIONAL_HEADER64)pIOH)->DataDirectory[u].Size);
		else
			printf(
				"   %-30s"DWMASK" "DWMASK,
				pch,
				((PIMAGE_OPTIONAL_HEADER32)pIOH)->DataDirectory[u].VirtualAddress,
				((PIMAGE_OPTIONAL_HEADER32)pIOH)->DataDirectory[u].Size);
		// print section name if possible
		cSec[0] = 0;
		if (b64Bit)
			pSH = PE_RvaToSection(
				pFH,
				((PIMAGE_OPTIONAL_HEADER64)pIOH)->DataDirectory[u].VirtualAddress);
		else
			pSH = PE_RvaToSection(
				pFH,
				((PIMAGE_OPTIONAL_HEADER32)pIOH)->DataDirectory[u].VirtualAddress);
        ExtractSectionName(pSH, cSec, sizeof(cSec));
        if (cSec[0])
			printf("  (\"%s\")", cSec);
		newline
	}
	nextline;

	return;
}

template <class T> BOOL PE_DumpNtHeaders3264(T* pNT)
{
	// PE check
	if (pNT->Signature != IMAGE_NT_SIGNATURE)
		return FALSE; // ERR

	//
	// file header
	//
	PE_DumpFileHeader(&pNT->FileHeader);

	//
	// optional header
	//
	PE_DumpOptionalHeader(
		(PIMAGE_OPTIONAL_HEADER)&pNT->OptionalHeader,
		&pNT->FileHeader);

	return TRUE; // OK
}

//
// also needed to dump OBJs
//
void PE_DumpSectionHeader(PIMAGE_SECTION_HEADER pSH)
{
	char  cSec[9];
	UINT  ucFound, u2;

	//
	// print hdr items
	//
	printf("    Name:                  ");
	if ( ExtractSectionName(pSH, cSec, sizeof(cSec)) )
		printf("%s", cSec);
	newline
	printf("    VirtualSize:           "DWMASK"\n", pSH->Misc.VirtualSize);
	printf("    VirtualAddress:        "DWMASK"\n", pSH->VirtualAddress);
	printf("    SizeOfRawData:         "DWMASK"\n", pSH->SizeOfRawData);
	printf("    PointerToRawData:      "DWMASK"\n", pSH->PointerToRawData);
	printf("    PointerToRelocations:  "DWMASK"\n", pSH->PointerToRelocations);
	printf("    PointerToLinenumbers:  "DWMASK"\n", pSH->NumberOfLinenumbers);
	printf("    NumberOfRelocations:   "WMASK"\n", pSH->NumberOfRelocations);
	printf("    NumberOfLinenumbers:   "WMASK"\n", pSH->NumberOfLinenumbers);
	printf("    Characteristics:       "DWMASK"\n", pSH->Characteristics);

	// list section flags
	ucFound = 0;
	for (u2 = 0; u2 < ARRAY_ITEMS(PESectionFlags); u2++)
	{
		if ( TESTBIT(pSH->Characteristics, PESectionFlags[u2].dwFlag) )
		{
			if (!ucFound)
				printf("    (");
			else
				printf(", ");
			printf("%s", PESectionFlags[u2].szFlag);
			++ucFound;
		}
	}
	// list alignment flags
	for (u2 = 0; u2 < ARRAY_ITEMS(PESectionAlignFlags); u2++)
	{
		if ((pSH->Characteristics & IMAGE_SCN_ALIGN_MASK) == PESectionAlignFlags[u2].dwFlag)
		{
			if (!ucFound)
				printf("    (");
			else
				printf(", ");
			printf("%s", PESectionAlignFlags[u2].szFlag);
			++ucFound;
			break; // flags !
		}
	}
	if (ucFound)
		printf(")\n");
	newline

	return;
}

//
// 32/64bit don't have to be handled twice here
//
void PE_DumpObjectTable(PIMAGE_NT_HEADERS pNT)
{
	IMAGE_SECTION_HEADER  *pSH;
	UINT                  u;

	// print title
	printf("->Section Header Table\n");

	//
	// dump section header table
	//
	pSH = IMAGE_FIRST_SECTION(pNT);
	for (u = 0; u < pNT->FileHeader.NumberOfSections; u++)
	{
		// print item hdr
		printf("   %u. item:\n", u + 1);

		PE_DumpSectionHeader(pSH);

		// next sec hdr
		++pSH;
	}

	return;
}

BOOL PE_DumpImportTable(PPE_HINTS pPE)
{
	IMAGE_IMPORT_DESCRIPTOR   *pIID;
	IMAGE_IMPORT_BY_NAME      *pIIBN;
	DWORD                     *pdwThunk;
	ULONGLONG                 *pqwThunk;
	char*                     szDllName, *szTime;
	UINT                      iIID;

	// print title
	printf("->Import Table\n");

	// get ptr to 1st IID
	pIID = (PIMAGE_IMPORT_DESCRIPTOR)PE_GetDirectoryEntryPtr(
		pPE->pNT,
		IMAGE_DIRECTORY_ENTRY_IMPORT);
	if (!pIID)
	{
		printf("   Not present !\n\n");
		return FALSE; // ERR
	}
	if (IsBadReadPtr((void*)pIID, sizeof(IMAGE_IMPORT_DESCRIPTOR)))
	{
		printf("   Image corrupted !\n\n");
		return FALSE; // ERR
	}

	//
	// print...
	//
	__try
	{
		iIID = 0;
		while (pIID->FirstThunk)
		{
			// print item hdr
			printf("   %u. ImageImportDescriptor:\n", iIID + 1);

			// print IID info
			printf("    OriginalFirstThunk:  "DWMASK"\n", pIID->OriginalFirstThunk);
			printf("    TimeDateStamp:       "DWMASK, pIID->TimeDateStamp);
			szTime = TimeDateStampToStr(pIID->TimeDateStamp);
			if (szTime)
				printf("  (GMT: %s)", szTime);
			nextline;
			printf("    ForwarderChain:      "DWMASK"\n", pIID->ForwarderChain);
			printf("    Name:                "DWMASK, pIID->Name);
			szDllName = (char*)PE_RvaToPtr(pPE->pNT, pIID->Name);
			if (szDllName)
				printf("  (\"%s\")", szDllName);
			newline
			printf("    FirstThunk:          "DWMASK"\n", pIID->FirstThunk);
			newline

			//
			// print import symbols
			//

			// print grid
			printf("    Ordinal/Hint API name\n");
			printf("    ------------ ---------------------------------------\n");
			// get ptr to first thunk
			if (pIID->OriginalFirstThunk)
				pdwThunk = (PDWORD)PE_RvaToPtr(pPE->pNT, pIID->OriginalFirstThunk);
			else
				pdwThunk = (PDWORD)PE_RvaToPtr(pPE->pNT, pIID->FirstThunk);
			if (!pdwThunk)
			{
				printf("    Invalid thunk pointer !\n");
				goto NextIID;
			}
			// process thunks
			pqwThunk = (PULONGLONG)pdwThunk;
			if (PE.b64Bit)
				while (*pqwThunk)
				{
					if (IMAGE_SNAP_BY_ORDINAL64(*pqwThunk)) // Ordinal ?
						printf("    "WMASK"\n", IMAGE_ORDINAL64(*pqwThunk));
					else
					{
						// process import by name
						pIIBN = (PIMAGE_IMPORT_BY_NAME)PE_RvaToPtr(pPE->pNT, (DWORD)*pqwThunk);
                        if (!pIIBN)
							printf("    Bad RVA in thunk !\n");
						else
							printf("    "WMASK"       \"%s\"\n", pIIBN->Hint, &pIIBN->Name);
					}
					// next thunk
					++pqwThunk;
				}
			else
				while (*pdwThunk)
				{
					if (IMAGE_SNAP_BY_ORDINAL32(*pdwThunk)) // Ordinal ?
						printf("    "WMASK"\n", IMAGE_ORDINAL32(*pdwThunk));
					else
					{
						// process import by name
						pIIBN = (PIMAGE_IMPORT_BY_NAME)PE_RvaToPtr(pPE->pNT, (DWORD)*pdwThunk);
                        if (!pIIBN)
							printf("    Bad RVA in thunk !\n");
						else
							printf("    "WMASK"       \"%s\"\n", pIIBN->Hint, &pIIBN->Name);
					}
					// next thunk
					++pdwThunk;
				}
NextIID:
			// next IID
			newline
			++pIID;
			++iIID;
		}
	}
	__except(EXCEPTION_EXECUTE_HANDLER)
	{
		newline
		printf("    Access violation !\n");
		newline
		return FALSE; // ERR
	}

	newline	

	return TRUE; // OK
}

//
// code not tested on PE32+ !
//
BOOL PE_DumpExportTable(PPE_HINTS pPE)
{
	IMAGE_EXPORT_DIRECTORY  *pET;
	char*                   szTime, *szDllName, *szSym;
	UINT                    uRva, uOrd;
	PDWORD                  pdwRvas, pdwNames;
	DWORD                   dwSymNameRva;
	PWORD                   pwCurOrd, pwOrds;
	BOOL                    bFound;

	// print title
	printf("->Export Table\n");

	// get dir entry ptr
	pET = (PIMAGE_EXPORT_DIRECTORY)PE_GetDirectoryEntryPtr(pPE->pNT, IMAGE_DIRECTORY_ENTRY_EXPORT);
	if (!pET)
	{
		printf("   Not present !\n\n");
		return FALSE; // ERR
	}
	if (IsBadReadPtr((void*)pET, sizeof(IMAGE_EXPORT_DIRECTORY)))
	{
		printf("   Image corrupted !\n\n");
		return FALSE; // ERR
	}

	//
	// dump ET info
	//
	printf("   Characteristics:        "DWMASK"\n", pET->Characteristics);
	printf("   TimeDateStamp:          "DWMASK, pET->TimeDateStamp);
	szTime = TimeDateStampToStr(pET->TimeDateStamp);
	if (szTime)
		printf("  (GMT: %s)", szTime);
	newline
	printf("   MajorVersion:           "WMASK"\n", pET->MajorVersion);
	printf("   MinorVersion:           "WMASK, pET->MinorVersion);
	printf("  -> %u.%02u\n", pET->MajorVersion, pET->MinorVersion);
	printf("   Name:                   "DWMASK, pET->Name);
	szDllName = (char*)PE_RvaToPtr(pPE->pNT, pET->Name);
	if (szDllName)
		printf("  (\"%s\")", szDllName);
	newline
	printf("   Base:                   "DWMASK"\n", pET->Base);
	printf("   NumberOfFunctions:      "DWMASK"\n", pET->NumberOfFunctions);
	printf("   NumberOfNames:          "DWMASK"\n", pET->NumberOfNames);
	printf("   AddressOfFunctions:     "DWMASK"\n", pET->AddressOfFunctions);
	printf("   AddressOfNames:         "DWMASK"\n", pET->AddressOfNames);
	printf("   AddressOfNameOrdinals:  "DWMASK"\n", pET->AddressOfNameOrdinals);
	nextline;

	//
	// dump exported symbols
	//
	pwOrds    = (PWORD)PE_RvaToPtr(pPE->pNT, pET->AddressOfNameOrdinals);
	pdwRvas   = (PDWORD)PE_RvaToPtr(pPE->pNT, pET->AddressOfFunctions);
	pdwNames  = (PDWORD)PE_RvaToPtr(pPE->pNT, pET->AddressOfNames);
	if (pET->NumberOfFunctions && !pdwRvas)
	{
		printf("   Bad symbol RVA chain pointer !\n\n");
		return FALSE; // ERR
	}
	__try
	{
		// print grid hdr
		printf("   Ordinal RVA        Symbol Name\n");
		printf("   ------- ---------- ----------------------------------\n");
		for (uRva = 0; uRva < pET->NumberOfFunctions; uRva++)
		{
			// NULL - RVA ?
			if (!*pdwRvas)
				goto NextRva;

			//
			// find symbol name
			//
			szSym = NULL;
			bFound = FALSE;
			if (pwOrds && pdwNames)
			{
				// check for an fitting ordinal
				pwCurOrd = pwOrds;
				for (uOrd = 0; uOrd < pET->NumberOfNames; uOrd++)
				{
					if (*pwCurOrd == uRva)
					{
						bFound = TRUE;
						break;
					}
					// next ordinal
					++pwCurOrd;
				}
				if (bFound)
				{
					dwSymNameRva = *(PDWORD)((DWORD)pdwNames + uOrd * sizeof(DWORD));
					szSym = (char*)PE_RvaToPtr(pPE->pNT, dwSymNameRva);
					if (szSym)
						if (IsBadStringPtr(szSym, 200))
							szSym = NULL;
				}
			}

			// print grid entry
			printf(
				"   "WMASK"  "DWMASK" ", 
				uRva + pET->Base,
				*pdwRvas);
			if (!szSym && bFound) // no sym name but ordinal found ?
				printf("Error while grabbing symbol name !");
			else if (szSym)
				printf("\"%s\"", szSym);
			else
				printf(SHORT_NOT_PRESENT);
			nextline;

			// next RVA in chain
NextRva:
			++pdwRvas;
		}
	}
	__except(EXCEPTION_EXECUTE_HANDLER)
	{
		nextline;
		printf("   Access violation !\n");
		nextline;
		return FALSE; // ERR
	}
	newline

	return TRUE; // OK
}

BOOL PE_DumpExceptionDirectory(PPE_HINTS pPE)
{
	IMAGE_RUNTIME_FUNCTION_ENTRY  *pIRFE;
	UINT                          ucItems, u;

	// print title
	printf("->Runtime Function Table\n");

	// get ptr and item num
	pIRFE = (PIMAGE_RUNTIME_FUNCTION_ENTRY)PE_GetDirectoryEntryPtr(
		pPE->pNT,
		IMAGE_DIRECTORY_ENTRY_EXCEPTION);
	if (!pIRFE)
	{
		printf("   Not present !\n\n");
		return FALSE; // ERR
	}
	if ( IsBadReadPtr((void*)pIRFE, sizeof(IMAGE_RUNTIME_FUNCTION_ENTRY)) )
	{
		printf("   Image corrupted !\n\n");
		return FALSE; // ERR
	}
	ucItems = PE_GetDirectoryPtr(pPE->pNT, IMAGE_DIRECTORY_ENTRY_EXCEPTION)->Size /
		sizeof(IMAGE_RUNTIME_FUNCTION_ENTRY);
	if (!ucItems)
	{
		printf("   No items present !\n\n");
		return FALSE; // ERR
	}

	//
	// dump items
	//

	// print grid header
	printf("   Start      End        Unwind\n");
	printf("   ---------- ---------- ----------\n");

	__try
	{
		for (u = 0; u < ucItems; u++)
		{
			printf("   "DWMASK" "DWMASK" "DWMASK"\n",
				pIRFE->BeginAddress,
				pIRFE->EndAddress,
				pIRFE->UnwindInfoAddress);
			// next chain item
			++pIRFE;
		}
	}
	__except(EXCEPTION_EXECUTE_HANDLER)
	{
		nextline;
		printf("   Access violation !\n");
		nextline;
	}
	nextline;

	return TRUE; // OK
}

//
// untested on PE32+
//
BOOL PE_DumpTLSTable(PPE_HINTS pPE)
{
	void* pTLSTbl;

	// print title
	printf("->TLS Table");
	if (pPE->b64Bit)
		printf(" 64");
	nextline;

	// get ptr
	pTLSTbl = PE_GetDirectoryEntryPtr(pPE->pNT, IMAGE_DIRECTORY_ENTRY_TLS);
	if (!pTLSTbl)
	{
		printf("   Not present !\n\n");
		return FALSE; // ERR
	}
	if ( IsBadReadPtr(pTLSTbl, sizeof(IMAGE_TLS_DIRECTORY32)) )
	{
		printf("   Image corrupted !\n\n");
		return FALSE; // ERR
	}

	//
	// dump TLS Table
	//

	if (!pPE->b64Bit)
	{
		// PE32
		printf("   StartAddressOfRawData:  "DWMASK"\n",
			((PIMAGE_TLS_DIRECTORY32)pTLSTbl)->StartAddressOfRawData);
		printf("   EndAddressOfRawData:    "DWMASK"\n",
			((PIMAGE_TLS_DIRECTORY32)pTLSTbl)->EndAddressOfRawData);
		printf("   AddressOfIndex:         "DWMASK"\n",
			((PIMAGE_TLS_DIRECTORY32)pTLSTbl)->AddressOfIndex);
		printf("   AddressOfCallBacks:     "DWMASK"\n",
			((PIMAGE_TLS_DIRECTORY32)pTLSTbl)->AddressOfCallBacks);
		printf("   SizeOfZeroFill:         "DWMASK"\n",
			((PIMAGE_TLS_DIRECTORY32)pTLSTbl)->SizeOfZeroFill);
		printf("   Characteristics:        "DWMASK"\n",
			((PIMAGE_TLS_DIRECTORY32)pTLSTbl)->Characteristics);
	}
	else
	{
		// PE32+
		printf("   StartAddressOfRawData:  "QWMASK"\n",
			((PIMAGE_TLS_DIRECTORY64)pTLSTbl)->StartAddressOfRawData);
		printf("   EndAddressOfRawData:    "QWMASK"\n",
			((PIMAGE_TLS_DIRECTORY64)pTLSTbl)->EndAddressOfRawData);
		printf("   AddressOfIndex:         "QWMASK"\n",
			((PIMAGE_TLS_DIRECTORY64)pTLSTbl)->AddressOfIndex);
		printf("   AddressOfCallBacks:     "QWMASK"\n",
			((PIMAGE_TLS_DIRECTORY64)pTLSTbl)->AddressOfCallBacks);
		printf("   SizeOfZeroFill:         "DWMASK"\n",
			((PIMAGE_TLS_DIRECTORY64)pTLSTbl)->SizeOfZeroFill);
		printf("   Characteristics:        "DWMASK"\n",
			((PIMAGE_TLS_DIRECTORY64)pTLSTbl)->Characteristics);
	}
	nextline;

	return TRUE; // OK
}

//
// untested on PE32+
//
BOOL PE_DumpLoadConfigDirectory(PPE_HINTS pPE)
{
	void*  pLCD;
	char*  szTDS;

	// print title
	printf("->Load Config Directory");
	if (pPE->b64Bit)
        printf(" 64");
	nextline;

	// get ptr
	pLCD = PE_GetDirectoryEntryPtr(pPE->pNT, IMAGE_DIRECTORY_ENTRY_LOAD_CONFIG);
	if (!pLCD)
	{
		printf("   Not present !\n\n");
		return FALSE; // ERR
	}
	if ( IsBadReadPtr((void*)pLCD, sizeof(IMAGE_LOAD_CONFIG_DIRECTORY32)) )
	{
		printf("   Image corrupted !\n\n");
		return FALSE; // ERR
	}

	//
	// dump LoadConfigDirectory
	//

	// process PE32/PE32+ independent items
	printf("   Characteristics:                "DWMASK"\n",
		((PIMAGE_LOAD_CONFIG_DIRECTORY32)pLCD)->Characteristics);
	printf("   TimeDateStamp:                  "DWMASK,
		((PIMAGE_LOAD_CONFIG_DIRECTORY32)pLCD)->TimeDateStamp);
	szTDS = TimeDateStampToStr(((PIMAGE_LOAD_CONFIG_DIRECTORY32)pLCD)->TimeDateStamp);
	if (szTDS)
		printf("  (GMT: %s)", szTDS);
	nextline;
	printf("   MajorVersion:                   "WMASK"\n",
		((PIMAGE_LOAD_CONFIG_DIRECTORY32)pLCD)->MajorVersion);
	printf("   MinorVersion:                   "WMASK,
		((PIMAGE_LOAD_CONFIG_DIRECTORY32)pLCD)->MinorVersion);
	printf(
		"  -> %u.%02u\n",
		((PIMAGE_LOAD_CONFIG_DIRECTORY32)pLCD)->MajorVersion,
		((PIMAGE_LOAD_CONFIG_DIRECTORY32)pLCD)->MinorVersion);
	printf("   GlobalFlagsClear:               "DWMASK"\n",
		((PIMAGE_LOAD_CONFIG_DIRECTORY32)pLCD)->GlobalFlagsClear);
	printf("   GlobalFlagsSet:                 "DWMASK"\n",
		((PIMAGE_LOAD_CONFIG_DIRECTORY32)pLCD)->GlobalFlagsSet);
	printf("   CriticalSectionDefaultTimeout:  "DWMASK"\n",
		((PIMAGE_LOAD_CONFIG_DIRECTORY32)pLCD)->CriticalSectionDefaultTimeout);

	// process lasting dependent elements
	if (PE.b64Bit)
	{
		// PE32+
		printf("   DeCommitFreeBlockThreshold:     "QWMASK"\n",
			((PIMAGE_LOAD_CONFIG_DIRECTORY64)pLCD)->DeCommitFreeBlockThreshold);
		printf("   DeCommitTotalFreeThreshold:     "QWMASK"\n",
			((PIMAGE_LOAD_CONFIG_DIRECTORY64)pLCD)->DeCommitTotalFreeThreshold);
		printf("   LockPrefixTable:                "QWMASK"\n",
			((PIMAGE_LOAD_CONFIG_DIRECTORY64)pLCD)->LockPrefixTable);
		printf("   MaximumAllocationSize:          "QWMASK"\n",
			((PIMAGE_LOAD_CONFIG_DIRECTORY64)pLCD)->MaximumAllocationSize);
		printf("   VirtualMemoryThreshold:         "QWMASK"\n",
			((PIMAGE_LOAD_CONFIG_DIRECTORY64)pLCD)->VirtualMemoryThreshold);
		printf("   ProcessAffinityMask:            "QWMASK"\n",
			((PIMAGE_LOAD_CONFIG_DIRECTORY64)pLCD)->ProcessAffinityMask);
		printf("   ProcessHeapFlags:               "DWMASK"\n",
			((PIMAGE_LOAD_CONFIG_DIRECTORY64)pLCD)->ProcessHeapFlags);
		printf("   CSDVersion:                     "WMASK"\n",
			((PIMAGE_LOAD_CONFIG_DIRECTORY64)pLCD)->CSDVersion);
		printf("   Reserved:                       "WMASK"\n",
			((PIMAGE_LOAD_CONFIG_DIRECTORY64)pLCD)->Reserved1);
		printf("   EditList:                       "QWMASK"\n",
			((PIMAGE_LOAD_CONFIG_DIRECTORY64)pLCD)->EditList);
		printf("   Reserved:                       "DWMASK"\n",
			((PIMAGE_LOAD_CONFIG_DIRECTORY64)pLCD)->Reserved[0]);
		printf("   Reserved:                       "DWMASK"\n",
			((PIMAGE_LOAD_CONFIG_DIRECTORY64)pLCD)->Reserved[1]);
	}
	else
	{
		// PE32
		printf("   DeCommitFreeBlockThreshold:     "DWMASK"\n",
			((PIMAGE_LOAD_CONFIG_DIRECTORY32)pLCD)->DeCommitFreeBlockThreshold);
		printf("   DeCommitTotalFreeThreshold:     "DWMASK"\n",
			((PIMAGE_LOAD_CONFIG_DIRECTORY32)pLCD)->DeCommitTotalFreeThreshold);
		printf("   LockPrefixTable:                "DWMASK"\n",
			((PIMAGE_LOAD_CONFIG_DIRECTORY32)pLCD)->LockPrefixTable);
		printf("   MaximumAllocationSize:          "DWMASK"\n",
			((PIMAGE_LOAD_CONFIG_DIRECTORY32)pLCD)->MaximumAllocationSize);
		printf("   VirtualMemoryThreshold:         "DWMASK"\n",
			((PIMAGE_LOAD_CONFIG_DIRECTORY32)pLCD)->VirtualMemoryThreshold);
		printf("   ProcessHeapFlags:               "DWMASK"\n",
			((PIMAGE_LOAD_CONFIG_DIRECTORY32)pLCD)->ProcessHeapFlags);
		printf("   ProcessAffinityMask:            "DWMASK"\n",
			((PIMAGE_LOAD_CONFIG_DIRECTORY32)pLCD)->ProcessAffinityMask);
		printf("   CSDVersion:                     "WMASK"\n",
			((PIMAGE_LOAD_CONFIG_DIRECTORY32)pLCD)->CSDVersion);
		printf("   Reserved:                       "WMASK"\n",
			((PIMAGE_LOAD_CONFIG_DIRECTORY32)pLCD)->Reserved1);
		printf("   EditList:                       "DWMASK"\n",
			((PIMAGE_LOAD_CONFIG_DIRECTORY32)pLCD)->EditList);
		printf("   Reserved:                       "DWMASK"\n",
			((PIMAGE_LOAD_CONFIG_DIRECTORY32)pLCD)->Reserved[0]);
	}
	nextline;

	return TRUE; // OK
}

//
// (32/64bit independent)
//
BOOL PE_DumpDebugDirectory(PPE_HINTS pPE)
{
	IMAGE_DEBUG_DIRECTORY *pIDD;
	UINT                  ucItems, u, i;
	char*                 szTDS;

	// print title
	printf("->Debug Directory\n");

	// get ptr
	pIDD = (PIMAGE_DEBUG_DIRECTORY)PE_GetDirectoryEntryPtr(
		pPE->pNT,
		IMAGE_DIRECTORY_ENTRY_DEBUG);
	if (!pIDD)
	{
		printf("   Not present !\n\n");
		return FALSE; // ERR
	}
	// calculate number of DebugDirectory entries
	ucItems = PE_GetDirectoryPtr(pPE->pNT, IMAGE_DIRECTORY_ENTRY_DEBUG)->Size /
		sizeof(IMAGE_DEBUG_DIRECTORY);
	if (!ucItems)
	{
		printf("   No items present !\n\n");
		return FALSE; // ERR
	}

	__try
	{
		for(u = 0; u < ucItems; u++)
		{
			// print item num
			printf("   %u. item:\n", u + 1);
			// dump info
			printf("    Characteristics:   "DWMASK"\n", pIDD->Characteristics);
			printf("    TimeDateStamp:     "DWMASK, pIDD->TimeDateStamp);
			szTDS = TimeDateStampToStr(pIDD->TimeDateStamp);
			if (szTDS)
				printf("  (GMT: %s)", szTDS);
			nextline;
			printf("    MajorVersion:      "WMASK"\n", pIDD->MajorVersion);
			printf("    MinorVersion:      "WMASK, pIDD->MinorVersion);
			printf("  -> %u.%02u\n", pIDD->MajorVersion, pIDD->MinorVersion);
			printf("    Type:              "DWMASK, pIDD->Type);
			for (i = 0; i < ARRAY_ITEMS(PEDebugTypes); i++)
				if (pIDD->Type == PEDebugTypes[i].dwFlag)
				{
					printf("  (%s)", PEDebugTypes[i].szFlag);
					break;
				}
			nextline;
			printf("    SizeOfData:        "DWMASK"\n", pIDD->SizeOfData);
			printf("    AddressOfRawData:  "DWMASK"\n", pIDD->AddressOfRawData);
			printf("    PointerToRawData:  "DWMASK"\n", pIDD->PointerToRawData);
			// next DebugDirectory
			++pIDD;
			nextline;
		}
	}
	__except(EXCEPTION_EXECUTE_HANDLER)
	{
		nextline;
		printf("   Access violation !\n");
		nextline;
		return FALSE; // ERR
	}
	nextline;

	return TRUE; // OK
}

//
// There's DelayImport 1.0 and DelayImport 2.0. 1.0 uses offsets (no RVAs!) for:
//  ImgDelayDescr.szName
//  ImgDelayDescr.phmod
//  ImgDelayDescr.pIAT
//  ImgDelayDescr.pINT
//  ImgDelayDescr.pBoundIAT
//  ImgDelayDescr.pUnloadIAT
// DelayImport 2.0 holds the "dlattrRva" (0x1) flag in "grAttrs" by which one can easily
// detect it.
//
// (not tested on DelayImport 2.0)
// (untested on PE32+)
//
BOOL PE_DumpDelayImports(PPE_HINTS pPE)
{
	ImgDelayDescr           *pDelayDescr;
	IMAGE_IMPORT_BY_NAME    *pIIBN;
	UINT                    uDescr;
	char*                   szTDS, *szDllName;
	BOOL                    bRvas;
	ULONGLONG               *pqwThunk;
	PDWORD                  pdwThunk;

	// print title
	printf("->Delay Import Directory\n");

	// get ptr to 1st descriptor
	pDelayDescr = (PImgDelayDescr)PE_GetDirectoryEntryPtr(
		pPE->pNT,
		IMAGE_DIRECTORY_ENTRY_DELAY_IMPORT);
	if (!pDelayDescr)
	{
		printf("   Not present !\n\n");
		return FALSE; // ERR
	}

	//
	// trace descriptors
	//
	__try
	{
		uDescr = 0;
		while (pDelayDescr->rvaDLLName)
		{
			// print item index
			printf("   %u. DelayImportDescriptor:\n", uDescr + 1);
			// dump descriptor info
			printf("    grAttrs:          "DWMASK, pDelayDescr->grAttrs);
			if ( TESTBIT(pDelayDescr->grAttrs, dlattrRva) )
			{
				printf("  (dlattrRva)");
				bRvas = TRUE;
			}
			else
				bRvas = FALSE;
			nextline;
			printf("    DLLName (R)VA:    "DWMASK, pDelayDescr->rvaDLLName);
			if (bRvas)
				szDllName = (char*)PE_RvaToPtr(pPE->pNT, pDelayDescr->rvaDLLName);
			else
				szDllName = (char*)PE_VaToPtr(pDelayDescr->rvaDLLName);
			if (szDllName)
				printf("  (\"%s\")", szDllName);
			nextline;
			printf("    Hmod (R)VA:       "DWMASK"\n", pDelayDescr->rvaHmod);
			printf("    IAT (R)VA:        "DWMASK"\n", pDelayDescr->rvaIAT);
			printf("    INT (R)VA:        "DWMASK"\n", pDelayDescr->rvaINT);
			printf("    BoundIAT (R)VA:   "DWMASK"\n", pDelayDescr->rvaBoundIAT);
			printf("    UnloadIAT (R)VA:  "DWMASK"\n", pDelayDescr->rvaUnloadIAT);
			printf("    TimeDateStamp:    "DWMASK, pDelayDescr->dwTimeStamp);
			szTDS = TimeDateStampToStr(pDelayDescr->dwTimeStamp);
			if (szTDS)
				printf("  (GMT: %s)", szTDS);
			nextline;
			//
			// trace thunk chain
			//
			nextline;
			if (bRvas)
				pdwThunk = (PDWORD)PE_RvaToPtr(pPE->pNT, pDelayDescr->rvaINT);
			else
				pdwThunk = (PDWORD)PE_VaToPtr(pDelayDescr->rvaINT);
			if (!pdwThunk)
			{
				printf("    Invalid INT (R)VA !\n");
				goto NextDescr;
			}
			pqwThunk = (PULONGLONG)pdwThunk;
			printf("    Ordinal/Hint API name\n");
			printf("    ------------ ---------------------------------------\n");
			if (PE.b64Bit)
				while (*pqwThunk)
				{
					if (IMAGE_SNAP_BY_ORDINAL64(*pqwThunk)) // Ordinal ?
						printf("    "WMASK"\n", IMAGE_ORDINAL64(*pqwThunk));
					else
					{
						// process import by name
						if (bRvas)
                            pIIBN = (PIMAGE_IMPORT_BY_NAME)PE_RvaToPtr(pPE->pNT, (DWORD)*pqwThunk);
						else
							pIIBN = (PIMAGE_IMPORT_BY_NAME)PE_VaToPtr((DWORD)*pqwThunk);
                        if (!pIIBN)
							printf("    Bad (R)VA in thunk !\n");
						else
							printf("    "WMASK"       \"%s\"\n", pIIBN->Hint, &pIIBN->Name);
					}
					// next thunk
					++pqwThunk;
				}
			else
				while (*pdwThunk)
				{
					if (IMAGE_SNAP_BY_ORDINAL32(*pdwThunk)) // Ordinal ?
						printf("    "WMASK"\n", IMAGE_ORDINAL32(*pdwThunk));
					else
					{
						// process import by name
						if (bRvas)
                            pIIBN = (PIMAGE_IMPORT_BY_NAME)PE_RvaToPtr(pPE->pNT, (DWORD)*pdwThunk);
						else
							pIIBN = (PIMAGE_IMPORT_BY_NAME)PE_VaToPtr(*pdwThunk);
                        if (!pIIBN)
							printf("    Bad (R)VA in thunk !\n");
						else
							printf("    "WMASK"       \"%s\"\n", pIIBN->Hint, &pIIBN->Name);
					}
					// next thunk
					++pdwThunk;
				}
NextDescr:
			// next descr
			++uDescr;
			++pDelayDescr;
			nextline;
		}
	}
	__except(EXCEPTION_EXECUTE_HANDLER)
	{
        nextline;
		printf("   Access violation !\n");
		nextline;
		return FALSE; // ERR
	}

	return TRUE; // OK
}

//
// (PE32/PE32+ independent)
//
BOOL PE_DumpBaseRelocation(PPE_HINTS pPE)
{
	IMAGE_BASE_RELOCATION  *pIBR;
	IMAGE_SECTION_HEADER   *pSH;
	UINT                   ucItems, i, iBlock, u;
	WORD                   *pW;
	BYTE                   byType;
	BOOL                   bFound;
	DWORD                  dwRva;
	char                   cSecName[9];
	
	// print title
	printf("->Relocation Directory\n");

	// get ptr
	pIBR = (PIMAGE_BASE_RELOCATION)PE_GetDirectoryEntryPtr(
		pPE->pNT,
        IMAGE_DIRECTORY_ENTRY_BASERELOC);
	if (!pIBR)
	{
		printf("   Not present !\n\n");
		return FALSE; // ERR
	}

	__try
	{
		//
		// trace relocation blockes
		//
		iBlock = 0;
		while (pIBR->VirtualAddress)
		{
			// calculate the item count
			ucItems = (pIBR->SizeOfBlock - sizeof(IMAGE_BASE_RELOCATION)) / sizeof(WORD);
			// print block info
			printf("   %u. Relocation Block:\n", ++iBlock);
			printf("    VirtualAddress:  "DWMASK, pIBR->VirtualAddress);
			pSH = PE_RvaToSection(pPE->pNT, pIBR->VirtualAddress);
			if (pSH)
				if ( ExtractSectionName(pSH, cSecName, sizeof(cSecName)) )
					printf("  (\"%s\")", cSecName);
			nextline;
			printf(
				"    SizeOfBlock:     "DWMASK"  ("WMASK" block entries)\n",
				pIBR->SizeOfBlock,
				ucItems);
			if (!ucItems)
			{
				nextline;
				break;
			}
			//
			// process block relocation items
			//
			// print grid header
			nextline;
			printf("    RVA        Type\n");
			printf("    ---------- -----------------\n");
			pW = MakePtr(PWORD, pIBR, sizeof(IMAGE_BASE_RELOCATION));
			for (i = 0; i < ucItems; i++)
			{
				// get type and RVA from reloc item
				byType  = *pW >> 12;
				dwRva   = (DWORD)(*pW & 0xFFF) + pIBR->VirtualAddress;
				// print grid entry
				if (byType == IMAGE_REL_BASED_ABSOLUTE)
					printf("    n/a        ");
				else
                    printf("    "DWMASK" ",	dwRva);
				bFound = FALSE;
                for (u = 0; u < ARRAY_ITEMS(PERelocationTypes); u++)
					if (PERelocationTypes[u].byFlag == (BYTE)byType)
					{
						printf("%s\n", PERelocationTypes[u].szFlag);
						bFound = TRUE;
						break;
					}
				if (!bFound)
					printf("?\n");
				// next reloc item
				++pW;
			}
			// set pIBR where another block could start
			pIBR = MakePtr(PIMAGE_BASE_RELOCATION, pIBR, pIBR->SizeOfBlock);
			nextline;
		}
	}
	__except(EXCEPTION_EXECUTE_HANDLER)
	{
		nextline;
		printf("   Access violation !\n");
		nextline;
		return FALSE; // ERR
	}

	return TRUE; // OK
}

//
// (PE32/PE32+ independent)
//
BOOL PE_DumpBoundImportDirectory(PPE_HINTS pPE)
{
	IMAGE_BOUND_IMPORT_DESCRIPTOR  *pIBID;
	IMAGE_BOUND_FORWARDER_REF      *pIBFR;
	IMAGE_DATA_DIRECTORY           *pIDD;
	char*                          szTDS;
	UINT                           iDescr, iForw;
	void*                          pIBIBase;

	// print title
	printf("->Bound Import Directory\n");

	// get ptr
	pIDD = (PIMAGE_DATA_DIRECTORY)PE_GetDirectoryPtr(
		pPE->pNT,
		IMAGE_DIRECTORY_ENTRY_BOUND_IMPORT);
	if (!pIDD->VirtualAddress)
	{
		printf("   Not present !\n\n");
		return FALSE; // ERR
	}
	if ( pIDD->VirtualAddress < PE_CalcRealHeaderSize(pPE->pNT) ) // in a section ?
		pIBID = MakePtr(PIMAGE_BOUND_IMPORT_DESCRIPTOR, pPE->pImage, pIDD->VirtualAddress);
	else
        pIBID = (PIMAGE_BOUND_IMPORT_DESCRIPTOR)PE_GetDirectoryEntryPtr(
			pPE->pNT,
			IMAGE_DIRECTORY_ENTRY_BOUND_IMPORT);
	pIBIBase = (void*)pIBID;

	__try
	{
		//
		// trace IMAGE_BOUND_IMPORT_DESCRIPTORs
		//
		iDescr = 0;
		while (pIBID->TimeDateStamp)
		{
			printf("   %u. BoundImportDescriptor:\n", iDescr + 1);
			// dump current IBID
			printf("    TimeDateStamp:                "DWMASK, pIBID->TimeDateStamp);
			szTDS = TimeDateStampToStr(pIBID->TimeDateStamp);
			if (szTDS)
				printf("  (GMT: %s)", szTDS);
			nextline;
			printf(
				"    OffsetModuleName:             "WMASK"  (\"%s\")\n",
				pIBID->OffsetModuleName,
				(char*)((DWORD)pIBIBase + (DWORD)pIBID->OffsetModuleName));
			printf("    NumberOfModuleForwarderRefs:  "WMASK"\n", pIBID->NumberOfModuleForwarderRefs);
			//
            // dump forwarder refs
			//
			pIBFR = MakePtr(PIMAGE_BOUND_FORWARDER_REF, pIBID,
				sizeof(IMAGE_BOUND_IMPORT_DESCRIPTOR));
			for (iForw = 0; iForw < pIBID->NumberOfModuleForwarderRefs; iForw++)
			{
				printf("     %u. ModuleForwarderReference:\n", iForw + 1);
				printf("      TimeDateStamp:     "DWMASK, pIBFR->TimeDateStamp);
				szTDS = TimeDateStampToStr(pIBFR->TimeDateStamp);
				if (szTDS)
					printf("  (GMT: %s)", szTDS);
				nextline;
				printf("      OffsetModuleName:  "WMASK"  (\"%s\")\n", pIBFR->OffsetModuleName,
					(char*)((DWORD)pIBIBase + pIBFR->OffsetModuleName));
				printf("      Reserved:          "WMASK"\n", pIBFR->Reserved);
				++pIBFR; // next one
			}
			// goto next IBID...addr dependent of IBFR num!
			pIBID = MakePtr(
				PIMAGE_BOUND_IMPORT_DESCRIPTOR,
				pIBID,
				sizeof(IMAGE_BOUND_IMPORT_DESCRIPTOR)
				+ pIBID->NumberOfModuleForwarderRefs * sizeof(IMAGE_BOUND_FORWARDER_REF));
			++iDescr;
			nextline;
		}
	}
	__except(EXCEPTION_EXECUTE_HANDLER)
	{
		nextline;
		printf("   Access violation !\n");
		nextline;
		return FALSE; // ERR
	}

	return TRUE; // OK
}

BOOL PE_DumpCopyrightsDirectory(PPE_HINTS pPE)
{
	IMAGE_DATA_DIRECTORY  *pIDD;
	void*                 pData;

	// print title
	printf("->Architecture Directory\n");

	// get ptr
	pIDD = PE_GetDirectoryPtr(pPE->pNT, IMAGE_DIRECTORY_ENTRY_ARCHITECTURE);
	if (!pIDD->VirtualAddress)
	{
		printf("   Not present !\n\n");
		return FALSE; // ERR
	}
	pData = (void*)PE_GetDirectoryEntryPtr(
		pPE->pNT,
		IMAGE_DIRECTORY_ENTRY_ARCHITECTURE);
	if ( IsBadReadPtr(pData, pIDD->Size) )
	{
		printf("   Image corrupted !\n\n");
		return FALSE; // ERR
	}
	//
	// dump
	//
	HexDump(pData, (DWORD)pData - (DWORD)pPE->pImage, pIDD->Size);
	nextline;

	return TRUE; // OK
}

BOOL PE_DumpImagePartitions(PPE_HINTS ppe)
{
	DWORD                 dwHdrSize;
	UINT                  u;
	IMAGE_SECTION_HEADER  *pSH;
	char                  cSec[9];

	// print title
	printf("->Partition Hex Dump\n");

	//
	// dump PE header
	//
	dwHdrSize = PE_CalcRealHeaderSize(ppe->pNT);
	printf("   PE Header (size: "DWMASK"):\n", dwHdrSize);
	HexDump(ppe->pImage, 0, dwHdrSize);
    
	//
	// dump sections
	//
	__try
	{
		pSH = IMAGE_FIRST_SECTION(ppe->pNT);
		for (u = 0; u < ppe->pNT->FileHeader.NumberOfSections; u++)
		{
			nextline;
			// print title
			ExtractSectionName(pSH, cSec, sizeof(cSec));
			printf(
				"   %u. Section: \"%s\" (size: "DWMASK")\n",
				u + 1,
				cSec,
				pSH->SizeOfRawData);
			// dump
			HexDump(
				(void*)((DWORD)ppe->pImage + pSH->PointerToRawData),
				pSH->PointerToRawData,
				pSH->SizeOfRawData);
			++pSH; // point to next SH
		}
	}
	__except(EXCEPTION_EXECUTE_HANDLER)
	{
		nextline;
		printf("   Access violation !\n");
		nextline;
		return FALSE; // ERR
	}
	nextline;

	return TRUE; // OK
}

//
// (PE32/PE32+ independent)
//
BOOL PE_DumpCOMDirectory(PPE_HINTS pPE)
{
    IMAGE_COR20_HEADER   *pICH;
	UINT                 i;
	BOOL                 bFound;

	// print title
	printf("->COM Descriptor\n");

	// get ptr
	pICH = (PIMAGE_COR20_HEADER)PE_GetDirectoryEntryPtr(pPE->pNT,
		IMAGE_DIRECTORY_ENTRY_COM_DESCRIPTOR);
	if (!pICH)
	{
		printf("   Not present !\n\n");
		return FALSE; // ERR
	}

	//
	// dump
	//
	__try
	{
		printf("   cb:                   "DWMASK"\n", pICH->cb);
		printf("   MajorRuntimeVersion:  "WMASK"\n", pICH->MajorRuntimeVersion);
		printf("   MinorRuntimeVersion:  "WMASK, pICH->MinorRuntimeVersion);
		printf("  -> %u.%02u\n", pICH->MajorRuntimeVersion, pICH->MinorRuntimeVersion);
		printf("   Flags:                "DWMASK, pICH->Flags);
		bFound = FALSE;
		for (i = 0; i < ARRAY_ITEMS(PEComEntryPointFlags); i++)
			if ( TESTBIT(PEComEntryPointFlags[i].dwFlag, pICH->Flags) )
			{
				if (!bFound)
					printf("  (");
				else
					printf(", ");
				printf(PEComEntryPointFlags->szFlag);
				bFound = TRUE;
			}
		if (bFound)
			printf(")");
		nextline;
		nextline;
		// dump data directories
		printf("   DataDirectory                 RVA        Size\n");
		printf("   -------------                 ---------- ----------\n");
		i = 0;
		printf("   %-29s "DWMASK" "DWMASK"\n", szCOMDirectory[i++], pICH->MetaData.VirtualAddress,
			pICH->MetaData.Size);
		printf("   %-29s "DWMASK" "DWMASK"\n", szCOMDirectory[i++], pICH->Resources.VirtualAddress,
			pICH->Resources.Size);
		printf("   %-29s "DWMASK" "DWMASK"\n", szCOMDirectory[i++], pICH->StrongNameSignature.VirtualAddress,
			pICH->StrongNameSignature.Size);
		printf("   %-29s "DWMASK" "DWMASK"\n", szCOMDirectory[i++], pICH->CodeManagerTable.VirtualAddress,
			pICH->CodeManagerTable.Size);
		printf("   %-29s "DWMASK" "DWMASK"\n", szCOMDirectory[i++], pICH->VTableFixups.VirtualAddress,
			pICH->VTableFixups.Size);
		printf("   %-29s "DWMASK" "DWMASK"\n", szCOMDirectory[i++], pICH->ExportAddressTableJumps.VirtualAddress,
			pICH->ExportAddressTableJumps.Size);
		printf("   %-29s "DWMASK" "DWMASK"\n", szCOMDirectory[i], pICH->ManagedNativeHeader.VirtualAddress,
			pICH->ManagedNativeHeader.Size);
	}
	__except(EXCEPTION_EXECUTE_HANDLER)
	{
		nextline;
		printf("   Access violation !\n");
		nextline;
	}
	nextline;

	return TRUE; // OK
}

void PE_ProcessResourceEntry(DWORD dwLevel, BOOL bDetails, PIMAGE_RESOURCE_DIRECTORY pRootIRD,
			PIMAGE_RESOURCE_DIRECTORY_ENTRY preToDump)
{
	IMAGE_RESOURCE_DATA_ENTRY    *pData;
	IMAGE_RESOURCE_DIR_STRING_U  *ResStr;
	char                         cSpaces[50], cBuff[300];
	DWORD                        i;
	BOOL                         bStr, bResTypeName;

	//
	// dump current directory entry
	//
	lstrcpy(cSpaces, "     ");
	for (i = 0; i < dwLevel; i++)
		lstrcat(cSpaces, "    ");
	if (dwLevel == 0)
		printf("   ---------------------------------------------------------\n");
	// cBuff -> resource name/id
	bStr = FALSE;
	bResTypeName = FALSE;
	if (preToDump->NameIsString)
	{
		ResStr = (IMAGE_RESOURCE_DIR_STRING_U*)((DWORD)pRootIRD +
			preToDump->NameOffset);
		bStr = ResUStr2ASCII(ResStr, cBuff, sizeof(cBuff));
	}					
	if (!bStr)
		if (dwLevel == 0
			&& preToDump->Id < ARRAY_ITEMS(szResourceTypes))
		{
			lstrcpy(cBuff, szResourceTypes[preToDump->Id]);
			bStr = TRUE;
			bResTypeName = TRUE;
		}
	if (bDetails)
	{
		printf("%s[ResourceEntry]:\n", cSpaces);
		printf("%sName/Id:       "DWMASK, cSpaces, preToDump->Name);
		if (bStr && !bResTypeName)
			printf("  (\"%s\")", cBuff);
		else if (bStr && bResTypeName)
			printf("  (%s)", cBuff);
		nextline;
		printf("%sOffsetToData:  "DWMASK, cSpaces, preToDump->OffsetToData);
		if (preToDump->DataIsDirectory)
			printf("  (DATA_IS_DIRECTORY)");
	}
	else
	{
		printf("%sResEntry:  ID/Name: ", cSpaces, cBuff);
		if (bStr && !bResTypeName)
			printf("\"%s\"", cBuff);
		else if (bStr && bResTypeName)
			printf(cBuff);
		else
			printf(HEXMASK_S, preToDump->Id);
	}
	nextline;

	// entry just a stub for another directory ?
	if (preToDump->DataIsDirectory)
	{
		PE_ProcessResourceDirectory(dwLevel + 1, bDetails, pRootIRD,
			(PIMAGE_RESOURCE_DIRECTORY)((DWORD)pRootIRD + preToDump->OffsetToDirectory));
	}
	else
	{
		//
		// dump resource item
		//
		pData = MakePtr(PIMAGE_RESOURCE_DATA_ENTRY, pRootIRD, preToDump->OffsetToData);
		lstrcat(cSpaces, "  ");
		if (bDetails)
		{
			printf("%s[ResourceDataEntry]:\n", cSpaces);
			printf("%sOffsetToData (RVA):  "DWMASK"\n", cSpaces, pData->OffsetToData);
			printf("%sSize:                "DWMASK"\n", cSpaces, pData->Size);
			printf("%sCodePage:            "DWMASK"\n", cSpaces, pData->CodePage);
			printf("%sReserved:            "DWMASK"\n", cSpaces, pData->Reserved);
		}
		else
		{
			printf("%s ResData:  RVA: "HEXMASK_S"  Size: "HEXMASK_S"  Codepage: "HEXMASK_S"\n",
				cSpaces, pData->OffsetToData, pData->Size, pData->CodePage);
		}
		nextline;
	}

	return;
}

void PE_ProcessResourceDirectory(DWORD dwLevel, BOOL bDetails, PIMAGE_RESOURCE_DIRECTORY pRootIRD,
								 PIMAGE_RESOURCE_DIRECTORY prdToDump)
{
	DWORD                           dwEntries, i;
	IMAGE_RESOURCE_DIRECTORY_ENTRY  *pRE;
	char                            cSpaces[50], *szTDS;

	//
	// dump current resource directory
	//
	lstrcpy(cSpaces, "   ");
	for (i = 0; i < dwLevel; i++)
		lstrcat(cSpaces, "    ");
	if (bDetails)
	{
		printf("%s[Resource Directory (%u)]:\n", cSpaces, dwLevel);
		printf("%sCharacteristics:       "DWMASK"\n", cSpaces, prdToDump->Characteristics);
		printf("%sTimeDateStamp:         "DWMASK, cSpaces, prdToDump->TimeDateStamp);
		szTDS = TimeDateStampToStr(prdToDump->TimeDateStamp);
		if (szTDS)
			printf("  (%s)", szTDS);
		nextline;
		printf("%sMajorVersion:          "WMASK"\n", cSpaces, prdToDump->MajorVersion);
		printf("%sMinorVersion:          "WMASK, cSpaces, prdToDump->MinorVersion);
		printf("  -> %u.%02u\n", prdToDump->MajorVersion, prdToDump->MinorVersion);
		printf("%sNumberOfNamedEntries:  "WMASK"\n", cSpaces, prdToDump->NumberOfNamedEntries);
		printf("%sNumberOfIdEntries:     "WMASK"\n", cSpaces, prdToDump->NumberOfIdEntries);
	}
	else
	{
		printf("%sResDir (%u):  Name Entries: "HEXMASK_S"  ID Entries: "HEXMASK_S"\n",
			cSpaces, dwLevel, prdToDump->NumberOfNamedEntries, prdToDump->NumberOfIdEntries);
	}

	//
	// process directory entries
	//
	dwEntries = prdToDump->NumberOfIdEntries + prdToDump->NumberOfNamedEntries;
	pRE = IMAGE_RESOURCE_GET_DIR_ENTRY(prdToDump);
	for (i = 0; i < dwEntries; i++)
	{
		PE_ProcessResourceEntry(dwLevel, bDetails, pRootIRD, pRE);
		++pRE;
	}

	return;
}

BOOL PE_DumpResourceDirectory(PPE_HINTS pPE, BOOL bDetails)
{
	IMAGE_RESOURCE_DIRECTORY        *pRootIRD;

	// print title
	printf("->Resource Tree");
	if (bDetails)
		printf(" (detailed dump)\n");
	else
		printf(" (simple dump)\n");

	// get ptr
	pRootIRD = (IMAGE_RESOURCE_DIRECTORY*)PE_GetDirectoryEntryPtr(
		pPE->pNT,
		IMAGE_DIRECTORY_ENTRY_RESOURCE);
	if (!pRootIRD)
	{
		printf("   Not present !\n\n");
		return FALSE; // ERR
	}

	__try
	{	
		PE_ProcessResourceDirectory(0, bDetails, pRootIRD, pRootIRD);
	}
	__except(EXCEPTION_EXECUTE_HANDLER)
	{
		nextline;
		printf("   Access violation !\n");
		nextline;
	}
	nextline;

	return TRUE; // OK
}