
#include "common.h"

//
// Returns:
// NULL     - in case of an error
//
LPVOID MapFileR(char * targetfile)
{
	HANDLE   hFile,hFileMap;
	LPVOID   pMappedFile;
	
	hFile = CreateFile ( targetfile, GENERIC_READ,FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
	if (hFile == INVALID_HANDLE_VALUE)
	{
		return NULL;
	}
	hFileMap = CreateFileMapping (hFile, NULL, PAGE_READONLY, 0, 0,NULL);
	if (!hFileMap)
	{
		CloseHandle (hFile);
		return NULL;
	}
	pMappedFile = MapViewOfFile ( hFileMap, FILE_MAP_READ, 0, 0, 0);
	if (!pMappedFile)
	{
		CloseHandle (hFileMap);
		CloseHandle (hFile);
		return NULL;
	}
	CloseHandle(hFileMap);
	CloseHandle(hFile);

	return pMappedFile;
}

//
// returns:
// whether at least one character was killed at the end of the string
//
BOOL WipeCarriageReturn(char* szStr)
{
	char*  pch;
	DWORD  dwc;

	if (!szStr)
		return FALSE; // ERR

	dwc = lstrlen(szStr);
	if (!dwc)
		return FALSE; // ERR

	pch = (char*)((DWORD)szStr + dwc - 1);
	if (*pch > 0x19)
		return FALSE; // ERR

	while (*pch < 0x20)
	{
		--pch;
		if (szStr-1 == pch)
			break;
	}
	pch[1] = 0; // insert new NUL termination

	return TRUE;
}

//
// converts a UNICODE string into a single character string
//
// Args:
// dwcMaxCharToProcess - number of characters to process at "szWideStr" excluding NUL !
// dwcBuff             - size of output buffer
//
// Note:
// IN and OUT buffers can be identical
//
BOOL WideToSingleCharStrN(IN PWSTR szWideStr, IN DWORD dwcMaxCharToProcess, OUT PSTR szStrBuff, IN DWORD dwcBuff)
{
	DWORD  chars;
	void*  pStr;

	chars = lstrlenW(szWideStr);
	if (!chars)
		return FALSE; // ERR
	chars = __min(dwcMaxCharToProcess, chars);
	if (dwcBuff < chars+1)
		return FALSE; // ERR
	pStr = malloc( chars );
	if (!pStr)
		return FALSE; // ERR

	if (!WideCharToMultiByte(
			CP_OEMCP,
			0,
			szWideStr, chars,
			(PSTR)pStr, chars,
			NULL, NULL))
		return FALSE; // ERR

	memcpy(
		(void*)szStrBuff,
		(void*)pStr,
		chars + 1);
	szStrBuff[chars] = 0; // insert NUL

	// Cleanup
	free(pStr);

	return TRUE; // OK
}

//
// converts a Big Endian to Little Endian and vice versa
// (processor needs to be 486+ :)
//
DWORD EndianSwitch(IN DWORD dwVal)
{
	DWORD dwRet;

	__asm
	{
		MOV    EAX, dwVal
		BSWAP  EAX
		MOV    [dwRet], EAX
	}

	return dwRet;
}