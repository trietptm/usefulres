
#ifndef __DumpPE_h__
#define __DumpPE_h__

#include <windows.h>
#include "PESnoop.h"
#include "common.h"

//
// exported structures
//
typedef struct _BYTE_FLAG_STR_TABLE
{
	BYTE   byFlag;
	char*  szFlag;
} BYTE_FLAG_STR_TABLE, *PBYTE_FLAG_STR_TABLE;

typedef struct _WORD_FLAG_STR_TABLE
{
	WORD   wFlag;
	char*  szFlag;
} WORD_FLAG_STR_TABLE, *PWORD_FLAG_STR_TABLE;

typedef struct _DWORD_FLAG_STR_TABLE
{
	DWORD  dwFlag;
	char*  szFlag;
} DWORD_FLAG_STR_TABLE, *PDWORD_FLAG_STR_TABLE;

//
// exported functions
//
BOOL  PE_IsPE64(IMAGE_DOS_HEADER *pdh);
BOOL  PE_DumpDosHeader(void* pImage);
BOOL  PE_DumpNtHeaders(PPE_HINTS pPE);
void  PE_DumpObjectTable(PIMAGE_NT_HEADERS pNT);
BOOL  PE_DumpImportTable(PPE_HINTS pPE);
BOOL  PE_DumpExportTable(PPE_HINTS pPE);
BOOL  PE_DumpExceptionDirectory(PPE_HINTS pPE);
BOOL  PE_DumpTLSTable(PPE_HINTS pPE);
BOOL  PE_DumpLoadConfigDirectory(PPE_HINTS pPE);
BOOL  PE_DumpDebugDirectory(PPE_HINTS pPE);
BOOL  PE_DumpDelayImports(PPE_HINTS pPE);
BOOL  PE_DumpDelayImports(PPE_HINTS pPE);
BOOL  PE_DumpBaseRelocation(PPE_HINTS pPE);
BOOL  PE_DumpBoundImportDirectory(PPE_HINTS pPE);
BOOL  PE_DumpCopyrightsDirectory(PPE_HINTS pPE);
BOOL  PE_DumpImagePartitions(PPE_HINTS ppe);
BOOL  PE_DumpCOMDirectory(PPE_HINTS pPE);
BOOL  PE_DumpResourceDirectory(PPE_HINTS pPE, BOOL bDetails);
void  PE_DumpFileHeader(PIMAGE_FILE_HEADER pFH);
void  PE_DumpSectionHeader(PIMAGE_SECTION_HEADER pSH);
void  HexDump(void* pData, DWORD dwStartOff, DWORD dwBytes);
BOOL  ExtractSectionName(IN PIMAGE_SECTION_HEADER pSH, OUT char *pszBuff, IN DWORD dwBuffSize);
char* TimeDateStampToStr(DWORD dwTDS);
void  PE_DumpOptionalHeader(PIMAGE_OPTIONAL_HEADER pIOH, PIMAGE_FILE_HEADER pFH);
BOOL  PE_IsPE64(PIMAGE_OPTIONAL_HEADER pOH);

//
// exported variables
//
extern WORD_FLAG_STR_TABLE  PEMachine[29];

#endif // __DumpPE_h__