
#ifndef __DumpCoffLib_h__
#define __DumpCoffLib_h__

#include <windows.h>
#include "common.h"

//
// structures
//

//
// exported functions
//
BOOL  CLIB_IsCoffLibraryImage(void* pImage);
BOOL  CLIB_DumpLibraryImage(void* pImage, DWORD dwFlags);

//
// exported variables
//

#endif // __DumpCoffLib_h__