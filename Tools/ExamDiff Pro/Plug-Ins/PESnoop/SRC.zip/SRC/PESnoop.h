
#ifndef __PESnoop_h__
#define __PESnoop_h__

#include <windows.h>

//
// structures
//
typedef struct _PE_HINTS
{
	union
	{
		void*               pImage;
		IMAGE_DOS_HEADER    *pDH;
	};
	union
	{
		IMAGE_NT_HEADERS    *pNT;
		IMAGE_NT_HEADERS64  *pNT64;
	};
	BOOL                    b64Bit;
} PE_HINTS, *PPE_HINTS;

//
// constants
//
#define CMD_OBJ_FH      0x00000001
#define CMD_OBJ_OH      0x00000002
#define CMD_OBJ_SHT     0x00000004
#define CMD_OBJ_ST      0x00000008
#define CMD_OBJ_S       0x00000010
#define CMD_OBJ_ALL     (CMD_OBJ_FH | CMD_OBJ_OH | CMD_OBJ_SHT | CMD_OBJ_ST | CMD_OBJ_S)

#define CMD_LIB_AMH     0x00000020
#define CMD_LIB_ILR     0x00000040
#define CMD_LIB_LM      0x00000080
#define CMD_LIB_LNM     0x00000100
#define CMD_LIB_S       0x00000200
#define CMD_LIB_ALL     (CMD_LIB_AMH | CMD_LIB_ILR | CMD_LIB_LM | CMD_LIB_LNM | CMD_LIB_S)

//
// exported functions
//

//
// exported variables
//
extern PE_HINTS            PE;

#endif // __PESnoop_h__